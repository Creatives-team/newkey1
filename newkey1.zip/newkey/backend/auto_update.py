"""Auto-update utilities for the NewKey backend (UPDATES DISABLED)."""

from __future__ import annotations

import json
import os
import subprocess
import threading
import time
import zipfile
from typing import Any, Dict, Optional

from api_manifest import store_last_message
from config import (
    UPDATE_CHECK_INTERVAL_SECONDS,
    UPDATE_CONFIG_FILE,
    UPDATE_PENDING_INFO,
    UPDATE_PENDING_ZIP,
)
from http_client import ensure_http_client, get_http_client
from logger import logger
from paths import backend_path, get_plugin_dir
from steam_utils import detect_steam_install_path
from utils import (
    get_plugin_version,
    parse_version,
    read_json,
    write_json,
)

_UPDATE_CHECK_THREAD: Optional[threading.Thread] = None


def apply_pending_update_if_any() -> str:
    """Updates disabled."""
    return ""


def _fetch_github_latest(cfg: Dict[str, Any]) -> Dict[str, Any]:
    """Updates disabled."""
    return {}


def _download_and_extract_update(zip_url: str, pending_zip: str) -> bool:
    """Updates disabled."""
    return False


def check_for_update_once() -> str:
    """Updates disabled."""
    logger.log("AutoUpdate: Update check is disabled in the code.")
    return ""


def _periodic_update_check_worker():
    """Updates disabled."""
    pass


def _start_periodic_update_checks():
    """Updates disabled."""
    pass


def _check_and_donate_keys() -> None:
    """Check donateKeys setting and send keys if enabled."""
    try:
        from donate_keys import extract_valid_decryption_keys, send_donation_keys
        from settings.manager import _get_values_locked
        
        values = _get_values_locked()
        general = values.get("general", {})
        donate_keys_enabled = general.get("donateKeys", False)
        
        if not donate_keys_enabled:
            return
        
        steam_path = detect_steam_install_path()
        if not steam_path:
            logger.warn("NewKey: Cannot donate keys - Steam path not found")
            return
        
        pairs = extract_valid_decryption_keys(steam_path)
        if pairs:
            send_donation_keys(pairs)
        else:
            logger.log("NewKey: No valid keys found to donate")
            
    except Exception as exc:
        logger.warn(f"NewKey: Donate keys check failed: {exc}")


def _start_initial_check_worker():
    try:
        logger.log("AutoUpdate: Auto-updates are explicitly disabled.")
        # Check and donate keys after skipping update check
        _check_and_donate_keys()
    except Exception as exc:
        logger.warn(f"AutoUpdate: background check failed: {exc}")


def start_auto_update_background_check() -> None:
    """Kick off the initial check in a background thread."""
    threading.Thread(target=_start_initial_check_worker, daemon=True).start()


def restart_steam_internal() -> bool:
    """Internal helper used to restart Steam via bundled script."""
    script_path = backend_path("restart_steam.cmd")
    if not os.path.exists(script_path):
        logger.error(f"NewKey: restart script not found: {script_path}")
        return False
    try:
        CREATE_NO_WINDOW = 0x08000000
        subprocess.Popen(["cmd", "/C", script_path], creationflags=CREATE_NO_WINDOW)
        logger.log("NewKey: Restart script launched (hidden)")
        return True
    except Exception as exc:
        logger.error(f"NewKey: Failed to launch restart script: {exc}")
        return False


def restart_steam() -> bool:
    """Public method exposed to the frontend."""
    return restart_steam_internal()


def check_for_updates_now() -> Dict[str, Any]:
    """Expose a synchronous update check for the frontend."""
    logger.log("NewKey: Manual update check blocked (Updates Disabled).")
    return {"success": False, "error": "تم إيقاف التحديثات التلقائية من السورس كود."}


__all__ = [
    "apply_pending_update_if_any",
    "check_for_update_once",
    "check_for_updates_now",
    "restart_steam",
    "restart_steam_internal",
    "start_auto_update_background_check",
]