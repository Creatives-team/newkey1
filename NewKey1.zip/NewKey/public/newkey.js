// NewKey button injection (standalone plugin)
(function() {
    'use strict';
    
    // Forward logs to Millennium backend so they appear in the dev console
    function backendLog(message) {
        try {
            if (typeof Millennium !== 'undefined' && typeof Millennium.callServerMethod === 'function') {
                Millennium.callServerMethod('newkey', 'Logger.log', { message: String(message) });
            }
        } catch (err) {
            if (typeof console !== 'undefined' && console.warn) {
                console.warn('[NewKey] backendLog failed', err);
            }
        }
    }
    
    backendLog('NewKey script loaded');
    // anti-spam state
    const logState = { missingOnce: false, existsOnce: false };
    // click/run debounce state
    const runState = { inProgress: false, appid: null };
    
    const TRANSLATION_PLACEHOLDER = 'translation missing';

    function applyTranslationBundle(bundle) {
        if (!bundle || typeof bundle !== 'object') return;
        const stored = window.__NewKeyI18n || {};
        if (bundle.language) {
            stored.language = String(bundle.language);
        } else if (!stored.language) {
            stored.language = 'en';
        }
        if (bundle.strings && typeof bundle.strings === 'object') {
            stored.strings = bundle.strings;
        } else if (!stored.strings) {
            stored.strings = {};
        }
        if (Array.isArray(bundle.locales)) {
            stored.locales = bundle.locales;
        } else if (!Array.isArray(stored.locales)) {
            stored.locales = [];
        }
        stored.ready = true;
        stored.lastFetched = Date.now();
        window.__NewKeyI18n = stored;
    }

    function ensureNewKeyStyles() {
        if (document.getElementById('newkey-styles')) return;
        try {
            const style = document.createElement('style');
            style.id = 'newkey-styles';
            style.textContent = `
                .newkey-btn {
                    padding: 12px 24px;
                    background: rgba(0, 212, 255, 0.05);
                    border: 1px solid rgba(0, 212, 255, 0.2);
                    border-radius: 12px;
                    color: #00d4ff;
                    font-size: 15px;
                    font-weight: 600;
                    text-decoration: none;
                    transition: all 0.3s cubic-bezier(0.25, 1, 0.5, 1);
                    cursor: pointer;
                    box-shadow: 0 4px 12px rgba(0, 0, 0, 0.2);
                    backdrop-filter: blur(4px);
                    letter-spacing: 0.3px;
                }
                .newkey-btn:hover:not([data-disabled="1"]) {
                    background: rgba(0, 212, 255, 0.15);
                    transform: translateY(-2px);
                    box-shadow: 0 8px 24px rgba(0, 212, 255, 0.2);
                    border-color: rgba(0, 212, 255, 0.5);
                }
                .newkey-btn.primary {
                    background: linear-gradient(135deg, #00d4ff 0%, #007bf5 100%);
                    border: none;
                    color: #fff;
                    font-weight: 700;
                    box-shadow: 0 6px 16px rgba(0, 123, 245, 0.4);
                    text-shadow: 0 1px 2px rgba(0,0,0,0.2);
                }
                .newkey-btn.primary:hover:not([data-disabled="1"]) {
                    background: linear-gradient(135deg, #1aeaff 0%, #1a8ff5 100%);
                    transform: translateY(-2px) scale(1.02);
                    box-shadow: 0 8px 25px rgba(0, 123, 245, 0.6);
                }
                @keyframes fadeIn {
                    from { opacity: 0; backdrop-filter: blur(0px); }
                    to { opacity: 1; backdrop-filter: blur(16px); }
                }
                @keyframes slideUp {
                    from {
                        opacity: 0;
                        transform: scale(0.95) translateY(10px);
                    }
                    to {
                        opacity: 1;
                        transform: scale(1) translateY(0);
                    }
                }
                @keyframes pulse {
                    0%, 100% { opacity: 1; box-shadow: 0 0 10px rgba(0, 212, 255, 0.5); }
                    50% { opacity: 0.7; box-shadow: 0 0 20px rgba(0, 212, 255, 0.8); }
                }
                
                /* Custom Scrollbar for modern look */
                .newkey-scroll::-webkit-scrollbar {
                    width: 8px;
                }
                .newkey-scroll::-webkit-scrollbar-track {
                    background: rgba(0, 0, 0, 0.2);
                    border-radius: 4px;
                }
                .newkey-scroll::-webkit-scrollbar-thumb {
                    background: rgba(0, 212, 255, 0.3);
                    border-radius: 4px;
                }
                .newkey-scroll::-webkit-scrollbar-thumb:hover {
                    background: rgba(0, 212, 255, 0.5);
                }
            `;
            document.head.appendChild(style);
        } catch(err) { backendLog('NewKey: Styles injection failed: ' + err); }
    }

    function ensureFontAwesome() {
        if (document.getElementById('newkey-fontawesome')) return;
        try {
            const link = document.createElement('link');
            link.id = 'newkey-fontawesome';
            link.rel = 'stylesheet';
            link.href = 'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css';
            link.integrity = 'sha512-DTOQO9RWCH3ppGqcWaEA1BIZOC6xxalwEsw9c2QQeAIftl+Vegovlnee1c9QX4TctnWMn13TZye+giMm8e2LwA==';
            link.crossOrigin = 'anonymous';
            link.referrerPolicy = 'no-referrer';
            document.head.appendChild(link);
        } catch(err) { backendLog('NewKey: Font Awesome injection failed: ' + err); }
    }

    function showSettingsPopup() {
        if (document.querySelector('.newkey-settings-overlay') || settingsMenuPending) return;
        settingsMenuPending = true;
        ensureTranslationsLoaded(false).catch(function(){ return null; }).finally(function(){
            settingsMenuPending = false;
            if (document.querySelector('.newkey-settings-overlay')) return;

            try { const d = document.querySelector('.newkey-overlay'); if (d) d.remove(); } catch(_) {}
            ensureNewKeyStyles();
            ensureFontAwesome();

            const overlay = document.createElement('div');
            overlay.className = 'newkey-settings-overlay';
            overlay.style.cssText = 'position:fixed;inset:0;background:rgba(5, 8, 15, 0.85);backdrop-filter:blur(16px);z-index:99999;display:flex;align-items:center;justify-content:center;animation:fadeIn 0.2s ease-out;';

            const modal = document.createElement('div');
            modal.style.cssText = 'position:relative;background:linear-gradient(145deg, #0d1117 0%, #161b22 100%);color:#fff;border:1px solid rgba(255, 255, 255, 0.08);border-radius:16px;min-width:420px;max-width:600px;padding:32px;box-shadow:0 24px 48px rgba(0,0,0,0.8), 0 0 0 1px rgba(0, 212, 255, 0.1);animation:slideUp 0.3s cubic-bezier(0.25, 1, 0.5, 1);';

            const header = document.createElement('div');
            header.style.cssText = 'display:flex;justify-content:space-between;align-items:center;margin-bottom:24px;padding-bottom:16px;border-bottom:1px solid rgba(255, 255, 255, 0.05);';

            const title = document.createElement('div');
            title.style.cssText = 'font-size:24px;font-weight:800;letter-spacing:0.5px;background:linear-gradient(135deg, #00d4ff 0%, #007bf5 100%);-webkit-background-clip:text;-webkit-text-fill-color:transparent;text-shadow:0 4px 12px rgba(0, 212, 255, 0.3);';
            title.textContent = t('menu.title', 'NewKey · Menu');

            const iconButtons = document.createElement('div');
            iconButtons.style.cssText = 'display:flex;gap:12px;';

            function createIconButton(id, iconClass, titleKey, titleFallback) {
                const btn = document.createElement('a');
                btn.id = id;
                btn.href = '#';
                btn.style.cssText = 'display:flex;align-items:center;justify-content:center;width:40px;height:40px;background:rgba(255, 255, 255, 0.03);border:1px solid rgba(255, 255, 255, 0.08);border-radius:12px;color:#8b949e;font-size:18px;text-decoration:none;transition:all 0.3s ease;cursor:pointer;';
                btn.innerHTML = '<i class="fa-solid ' + iconClass + '"></i>';
                btn.title = t(titleKey, titleFallback);
                btn.onmouseover = function() { this.style.color = '#00d4ff'; this.style.borderColor = 'rgba(0, 212, 255, 0.4)'; this.style.background = 'rgba(0, 212, 255, 0.05)'; this.style.transform = 'translateY(-2px)'; this.style.boxShadow = '0 8px 16px rgba(0, 212, 255, 0.15)'; };
                btn.onmouseout = function() { this.style.color = '#8b949e'; this.style.borderColor = 'rgba(255, 255, 255, 0.08)'; this.style.background = 'rgba(255, 255, 255, 0.03)'; this.style.transform = 'translateY(0)'; this.style.boxShadow = 'none'; };
                iconButtons.appendChild(btn);
                return btn;
            }

            const body = document.createElement('div');
            body.style.cssText = 'font-size:14px;line-height:1.6;margin-bottom:8px;';

            const container = document.createElement('div');
            container.style.cssText = 'margin-top:16px;display:flex;flex-direction:column;gap:12px;align-items:stretch;';

            function createSectionLabel(key, fallback, marginTop) {
                const label = document.createElement('div');
                const topValue = typeof marginTop === 'number' ? marginTop : 16;
                label.style.cssText = 'font-size:12px;color:#8b949e;margin-top:' + topValue + 'px;margin-bottom:8px;font-weight:700;text-transform:uppercase;letter-spacing:1.5px;text-align:left;padding-left:4px;';
                label.textContent = t(key, fallback);
                container.appendChild(label);
                return label;
            }

            function createMenuButton(id, key, fallback, iconClass, isPrimary) {
                const btn = document.createElement('a');
                btn.id = id;
                btn.href = '#';
                btn.style.cssText = 'display:flex;align-items:center;justify-content:flex-start;gap:12px;padding:16px 24px;background:rgba(22, 27, 34, 0.6);border:1px solid rgba(255, 255, 255, 0.05);border-radius:12px;color:#e6edf3;font-size:15px;font-weight:500;text-decoration:none;transition:all 0.3s cubic-bezier(0.25, 1, 0.5, 1);cursor:pointer;position:relative;overflow:hidden;backdrop-filter:blur(4px);';
                const iconHtml = iconClass ? '<i class="fa-solid ' + iconClass + '" style="font-size:18px; color:#00d4ff; width:24px; text-align:center;"></i>' : '';
                const textSpan = '<span>' + t(key, fallback) + '</span>';
                btn.innerHTML = iconHtml + textSpan;
                btn.onmouseover = function() { this.style.background = 'rgba(30, 38, 48, 0.9)'; this.style.transform = 'translateY(-2px)'; this.style.boxShadow = '0 8px 20px rgba(0, 0, 0, 0.4)'; this.style.borderColor = 'rgba(0, 212, 255, 0.4)'; };
                btn.onmouseout = function() { this.style.background = 'rgba(22, 27, 34, 0.6)'; this.style.transform = 'translateY(0)'; this.style.boxShadow = 'none'; this.style.borderColor = 'rgba(255, 255, 255, 0.05)'; };
                container.appendChild(btn);
                return btn;
            }

            const discordBtn = createIconButton('nk-settings-discord', 'fa-brands fa-discord', 'menu.discord', 'Discord');
            const settingsManagerBtn = createIconButton('nk-settings-open-manager', 'fa-gear', 'menu.settings', 'Settings');
            const closeBtn = createIconButton('nk-settings-close', 'fa-xmark', 'settings.close', 'Close');

            createSectionLabel('menu.manageGameLabel', 'Manage Game');

            const removeBtn = createMenuButton('nk-settings-remove-lua', 'menu.removeNewKey', 'Remove via NewKey', 'fa-trash-can');
            removeBtn.style.display = 'none';
            // Custom hover for remove button
            removeBtn.onmouseover = function() { this.style.background = 'rgba(244, 63, 94, 0.1)'; this.style.transform = 'translateY(-2px)'; this.style.boxShadow = '0 8px 20px rgba(244, 63, 94, 0.2)'; this.style.borderColor = 'rgba(244, 63, 94, 0.5)'; this.querySelector('i').style.color = '#f43f5e'; this.style.color = '#f43f5e'; };
            removeBtn.onmouseout = function() { this.style.background = 'rgba(22, 27, 34, 0.6)'; this.style.transform = 'translateY(0)'; this.style.boxShadow = 'none'; this.style.borderColor = 'rgba(255, 255, 255, 0.05)'; this.querySelector('i').style.color = '#00d4ff'; this.style.color = '#e6edf3';};

            const fixesMenuBtn = createMenuButton('nk-settings-fixes-menu', 'menu.fixesMenu', 'Fixes Menu', 'fa-wrench');

            createSectionLabel('menu.advancedLabel', 'Advanced');
            const checkBtn = createMenuButton('nk-settings-check', 'menu.checkForUpdates', 'Check For Updates', 'fa-cloud-arrow-down');
            const fetchApisBtn = createMenuButton('nk-settings-fetch-apis', 'menu.fetchFreeApis', 'Fetch Free APIs', 'fa-server');

            body.appendChild(container);

            header.appendChild(title);
            header.appendChild(iconButtons);
            modal.appendChild(header);
            modal.appendChild(body);
            overlay.appendChild(modal);
            document.body.appendChild(overlay);

            if (checkBtn) {
                checkBtn.addEventListener('click', function(e){
                    e.preventDefault();
                    try { overlay.remove(); } catch(_) {}
                    try {
                        Millennium.callServerMethod('newkey', 'CheckForUpdatesNow', { contentScriptQuery: '' }).then(function(res){
                            try {
                                const payload = typeof res === 'string' ? JSON.parse(res) : res;
                                const msg = (payload && payload.message) ? String(payload.message) : nk('No updates available.');
                                ShowNewKeyAlert('NewKey', msg);
                            } catch(_) {}
                        });
                    } catch(_) {}
                });
            }

            if (discordBtn) {
                discordBtn.addEventListener('click', function(e){
                    e.preventDefault();
                    try { overlay.remove(); } catch(_) {}
                    const url = 'https://discord.gg/nsCGfP22';
                    try {
                        Millennium.callServerMethod('newkey', 'OpenExternalUrl', { url, contentScriptQuery: '' });
                    } catch(_) {}
                });
            }

            if (fetchApisBtn) {
                fetchApisBtn.addEventListener('click', function(e){
                    e.preventDefault();
                    try { overlay.remove(); } catch(_) {}
                    try {
                        Millennium.callServerMethod('newkey', 'FetchFreeApisNow', { contentScriptQuery: '' }).then(function(res){
                            try {
                                const payload = typeof res === 'string' ? JSON.parse(res) : res;
                                const ok = payload && payload.success;
                                const count = payload && payload.count;
                                const successText = nk('Loaded free APIs: {count}').replace('{count}', (count != null ? count : '?'));
                                const failText = (payload && payload.error) ? String(payload.error) : nk('Failed to load free APIs.');
                                const text = ok ? successText : failText;
                                ShowNewKeyAlert('NewKey', text);
                            } catch(_) {}
                        });
                    } catch(_) {}
                });
            }

            if (closeBtn) {
                closeBtn.addEventListener('click', function(e){
                    e.preventDefault();
                    overlay.remove();
                });
            }

            if (settingsManagerBtn) {
                settingsManagerBtn.addEventListener('click', function(e){
                    e.preventDefault();
                    try { overlay.remove(); } catch(_) {}
                    showSettingsManagerPopup(false, showSettingsPopup);
                });
            }

            if (fixesMenuBtn) {
                fixesMenuBtn.addEventListener('click', function(e){
                    e.preventDefault();
                    try {
                        const match = window.location.href.match(/https:\/\/store\.steampowered\.com\/app\/(\d+)/) || window.location.href.match(/https:\/\/steamcommunity\.com\/app\/(\d+)/);
                        const appid = match ? parseInt(match[1], 10) : (window.__NewKeyCurrentAppId || NaN);
                        if (isNaN(appid)) {
                            try { overlay.remove(); } catch(_) {}
                            const errText = t('menu.error.noAppId', 'Could not determine game AppID');
                            ShowNewKeyAlert('NewKey', errText);
                            return;
                        }

                        Millennium.callServerMethod('newkey', 'GetGameInstallPath', { appid, contentScriptQuery: '' }).then(function(pathRes){
                            try {
                                let isGameInstalled = false;
                                const pathPayload = typeof pathRes === 'string' ? JSON.parse(pathRes) : pathRes;
                                if (pathPayload && pathPayload.success && pathPayload.installPath) {
                                    isGameInstalled = true;
                                    window.__NewKeyGameInstallPath = pathPayload.installPath;
                                }
                                window.__NewKeyGameIsInstalled = isGameInstalled;
                                try { overlay.remove(); } catch(_) {}
                                showFixesLoadingPopupAndCheck(appid);
                            } catch(err) {
                                backendLog('NewKey: GetGameInstallPath error: ' + err);
                                try { overlay.remove(); } catch(_) {}
                            }
                        }).catch(function() {
                            try { overlay.remove(); } catch(_) {}
                            const errorText = t('menu.error.getPath', 'Error getting game path');
                            ShowNewKeyAlert('NewKey', errorText);
                        });
                    } catch(err) {
                        backendLog('NewKey: Fixes Menu button error: ' + err);
                    }
                });
            }

            try {
                const match = window.location.href.match(/https:\/\/store\.steampowered\.com\/app\/(\d+)/) || window.location.href.match(/https:\/\/steamcommunity\.com\/app\/(\d+)/);
                const appid = match ? parseInt(match[1], 10) : (window.__NewKeyCurrentAppId || NaN);
                if (!isNaN(appid) && typeof Millennium !== 'undefined' && typeof Millennium.callServerMethod === 'function') {
                    Millennium.callServerMethod('newkey', 'HasNewKeyForApp', { appid, contentScriptQuery: '' }).then(function(res){
                        try {
                            const payload = typeof res === 'string' ? JSON.parse(res) : res;
                            const exists = !!(payload && payload.success && payload.exists === true);
                            if (exists) {
                                const doDelete = function() {
                                    try {
                                        Millennium.callServerMethod('newkey', 'DeleteNewKeyForApp', { appid, contentScriptQuery: '' }).then(function(){
                                            try {
                                                window.__NewKeyButtonInserted = false;
                                                window.__NewKeyPresenceCheckInFlight = false;
                                                window.__NewKeyPresenceCheckAppId = undefined;
                                                addNewKeyButton();
                                                const successText = t('menu.remove.success', 'NewKey removed for this app.');
                                                ShowNewKeyAlert('NewKey', successText);
                                            } catch(err) {
                                                backendLog('NewKey: post-delete cleanup failed: ' + err);
                                            }
                                        }).catch(function(err){
                                            const failureText = t('menu.remove.failure', 'Failed to remove NewKey.');
                                            const errMsg = (err && err.message) ? err.message : failureText;
                                            ShowNewKeyAlert('NewKey', errMsg);
                                        });
                                    } catch(err) {
                                        backendLog('NewKey: doDelete failed: ' + err);
                                    }
                                };

                                removeBtn.style.display = 'flex';
                                removeBtn.onclick = function(e){
                                    e.preventDefault();
                                    try { overlay.remove(); } catch(_) {}
                                    const confirmMessage = t('menu.remove.confirm', 'Remove via NewKey for this game?');
                                    showNewKeyConfirm('NewKey', confirmMessage, function(){
                                        doDelete();
                                    }, function(){
                                        try { showSettingsPopup(); } catch(_) {}
                                    });
                                };
                            } else {
                                removeBtn.style.display = 'none';
                            }
                        } catch(_) {}
                    });
                }
            } catch(_) {}
        });
    }

    function ensureTranslationsLoaded(forceRefresh, preferredLanguage) {
        try {
            if (!forceRefresh && window.__NewKeyI18n && window.__NewKeyI18n.ready) {
                return Promise.resolve(window.__NewKeyI18n);
            }
            if (typeof Millennium === 'undefined' || typeof Millennium.callServerMethod !== 'function') {
                window.__NewKeyI18n = window.__NewKeyI18n || { language: 'en', locales: [], strings: {}, ready: false };
                return Promise.resolve(window.__NewKeyI18n);
            }
            const targetLanguage = (typeof preferredLanguage === 'string' && preferredLanguage) ? preferredLanguage :
                ((window.__NewKeyI18n && window.__NewKeyI18n.language) || '');
            return Millennium.callServerMethod('newkey', 'GetTranslations', { language: targetLanguage, contentScriptQuery: '' }).then(function(res){
                const payload = typeof res === 'string' ? JSON.parse(res) : res;
                if (!payload || payload.success !== true || !payload.strings) {
                    throw new Error('Invalid translation payload');
                }
                applyTranslationBundle(payload);
                updateButtonTranslations();
                return window.__NewKeyI18n;
            }).catch(function(err){
                backendLog('NewKey: translation load failed: ' + err);
                window.__NewKeyI18n = window.__NewKeyI18n || { language: 'en', locales: [], strings: {}, ready: false };
                return window.__NewKeyI18n;
            });
        } catch(err) {
            backendLog('NewKey: ensureTranslationsLoaded error: ' + err);
            window.__NewKeyI18n = window.__NewKeyI18n || { language: 'en', locales: [], strings: {}, ready: false };
            return Promise.resolve(window.__NewKeyI18n);
        }
    }

    function translateText(key, fallback) {
        if (!key) {
            return typeof fallback !== 'undefined' ? fallback : '';
        }
        try {
            const store = window.__NewKeyI18n;
            if (store && store.strings && Object.prototype.hasOwnProperty.call(store.strings, key)) {
                const value = store.strings[key];
                if (typeof value === 'string') {
                    const trimmed = value.trim();
                    if (trimmed && trimmed.toLowerCase() !== TRANSLATION_PLACEHOLDER) {
                        return value;
                    }
                }
            }
        } catch(_) {}
        return typeof fallback !== 'undefined' ? fallback : key;
    }

    function t(key, fallback) {
        return translateText(key, fallback);
    }

    function nk(text) {
        return t(text, text);
    }

    ensureTranslationsLoaded(false);

    let settingsMenuPending = false;
    
    function showTestPopup() {
        if (document.querySelector('.newkey-overlay')) return;
        try { const s = document.querySelector('.newkey-settings-overlay'); if (s) s.remove(); } catch(_) {}
        
        ensureNewKeyStyles();
        const overlay = document.createElement('div');
        overlay.className = 'newkey-overlay';
        overlay.style.cssText = 'position:fixed;inset:0;background:rgba(5, 8, 15, 0.85);backdrop-filter:blur(16px);z-index:99999;display:flex;align-items:center;justify-content:center;animation:fadeIn 0.2s ease-out;';

        const modal = document.createElement('div');
        modal.style.cssText = 'background:linear-gradient(145deg, #0d1117 0%, #161b22 100%);color:#fff;border:1px solid rgba(255, 255, 255, 0.08);border-radius:16px;min-width:400px;max-width:560px;padding:32px;box-shadow:0 24px 48px rgba(0,0,0,0.8), 0 0 0 1px rgba(0, 212, 255, 0.1);animation:slideUp 0.3s cubic-bezier(0.25, 1, 0.5, 1);';

        const title = document.createElement('div');
        title.style.cssText = 'font-size:24px;font-weight:800;letter-spacing:0.5px;margin-bottom:16px;background:linear-gradient(135deg, #00d4ff 0%, #007bf5 100%);-webkit-background-clip:text;-webkit-text-fill-color:transparent;text-shadow:0 4px 12px rgba(0, 212, 255, 0.3);';
        title.className = 'newkey-title';
        title.textContent = 'NewKey';

        const body = document.createElement('div');
        body.style.cssText = 'font-size:15px;line-height:1.4;margin-bottom:16px;color:#e6edf3;';
        body.className = 'newkey-status';
        body.textContent = nk('Working…');

        const progressWrap = document.createElement('div');
        progressWrap.style.cssText = 'background:rgba(255,255,255,0.05);height:12px;border-radius:6px;overflow:hidden;position:relative;display:none;border:1px solid rgba(255,255,255,0.1);';
        progressWrap.className = 'newkey-progress-wrap';
        const progressBar = document.createElement('div');
        progressBar.style.cssText = 'height:100%;width:0%;background:linear-gradient(90deg, #00d4ff 0%, #007bf5 100%);transition:width 0.1s linear;box-shadow:0 0 12px rgba(0, 212, 255, 0.6);';
        progressBar.className = 'newkey-progress-bar';
        progressWrap.appendChild(progressBar);

        const percent = document.createElement('div');
        percent.style.cssText = 'text-align:right;color:#8b949e;margin-top:8px;font-size:12px;display:none;font-weight:600;';
        percent.className = 'newkey-percent';
        percent.textContent = '0%';

        const btnRow = document.createElement('div');
        btnRow.style.cssText = 'margin-top:24px;display:flex;gap:12px;justify-content:flex-end;';
        const cancelBtn = document.createElement('a');
        cancelBtn.className = 'newkey-btn newkey-cancel-btn';
        cancelBtn.innerHTML = `<span>${nk('Cancel')}</span>`;
        cancelBtn.href = '#';
        cancelBtn.style.display = 'none';
        cancelBtn.onclick = function(e){ e.preventDefault(); cancelOperation(); };
        const hideBtn = document.createElement('a');
        hideBtn.className = 'newkey-btn primary newkey-hide-btn';
        hideBtn.innerHTML = `<span>${nk('Hide')}</span>`;
        hideBtn.href = '#';
        hideBtn.onclick = function(e){ e.preventDefault(); cleanup(); };
        btnRow.appendChild(cancelBtn);
        btnRow.appendChild(hideBtn);

        modal.appendChild(title);
        modal.appendChild(body);
        modal.appendChild(progressWrap);
        modal.appendChild(percent);
        modal.appendChild(btnRow);
        overlay.appendChild(modal);
        document.body.appendChild(overlay);

        function cleanup(){
            overlay.remove();
        }
        
        function cancelOperation(){
            try {
                const match = window.location.href.match(/https:\/\/store\.steampowered\.com\/app\/(\d+)/) || window.location.href.match(/https:\/\/steamcommunity\.com\/app\/(\d+)/);
                const appid = match ? parseInt(match[1], 10) : (window.__NewKeyCurrentAppId || NaN);
                if (!isNaN(appid) && typeof Millennium !== 'undefined' && typeof Millennium.callServerMethod === 'function') {
                    Millennium.callServerMethod('newkey', 'CancelAddViaNewKey', { appid, contentScriptQuery: '' });
                }
            } catch(_) {}
            const status = overlay.querySelector('.newkey-status');
            if (status) status.textContent = nk('Cancelled');
            const cancelBtn = overlay.querySelector('.newkey-cancel-btn');
            if (cancelBtn) cancelBtn.style.display = 'none';
            const hideBtn = overlay.querySelector('.newkey-hide-btn');
            if (hideBtn) hideBtn.innerHTML = `<span>${nk('Close')}</span>`;
            const wrap = overlay.querySelector('.newkey-progress-wrap');
            const percent = overlay.querySelector('.newkey-percent');
            if (wrap) wrap.style.display = 'none';
            if (percent) percent.style.display = 'none';
            runState.inProgress = false;
            runState.appid = null;
        }
    }

    function showFixesResultsPopup(data, isGameInstalled) {
        if (document.querySelector('.newkey-fixes-results-overlay')) return;
        try { const d = document.querySelector('.newkey-overlay'); if (d) d.remove(); } catch(_) {}
        try { const s = document.querySelector('.newkey-settings-overlay'); if (s) s.remove(); } catch(_) {}
        try { const f = document.querySelector('.newkey-fixes-results-overlay'); if (f) f.remove(); } catch(_) {}
        try { const l = document.querySelector('.newkey-loading-fixes-overlay'); if (l) l.remove(); } catch(_) {}

        ensureNewKeyStyles();
        const overlay = document.createElement('div');
        overlay.className = 'newkey-fixes-results-overlay';
        overlay.style.cssText = 'position:fixed;inset:0;background:rgba(5, 8, 15, 0.85);backdrop-filter:blur(16px);z-index:99999;display:flex;align-items:center;justify-content:center;animation:fadeIn 0.2s ease-out;';

        const modal = document.createElement('div');
        modal.style.cssText = 'position:relative;background:linear-gradient(145deg, #0d1117 0%, #161b22 100%);color:#fff;border:1px solid rgba(255, 255, 255, 0.08);border-radius:16px;min-width:580px;max-width:700px;max-height:80vh;display:flex;flex-direction:column;padding:32px;box-shadow:0 24px 48px rgba(0,0,0,0.8), 0 0 0 1px rgba(0, 212, 255, 0.1);animation:slideUp 0.3s cubic-bezier(0.25, 1, 0.5, 1);';

        const header = document.createElement('div');
        header.style.cssText = 'flex:0 0 auto;display:flex;justify-content:space-between;align-items:center;margin-bottom:24px;padding-bottom:16px;border-bottom:1px solid rgba(255, 255, 255, 0.05);';

        const title = document.createElement('div');
        title.style.cssText = 'font-size:24px;font-weight:800;letter-spacing:0.5px;background:linear-gradient(135deg, #00d4ff 0%, #007bf5 100%);-webkit-background-clip:text;-webkit-text-fill-color:transparent;text-shadow:0 4px 12px rgba(0, 212, 255, 0.3);';
        title.textContent = nk('NewKey · Fixes Menu');

        const iconButtons = document.createElement('div');
        iconButtons.style.cssText = 'display:flex;gap:12px;';

        function createIconButton(id, iconClass, titleKey, titleFallback) {
            const btn = document.createElement('a');
            btn.id = id;
            btn.href = '#';
            btn.style.cssText = 'display:flex;align-items:center;justify-content:center;width:40px;height:40px;background:rgba(255, 255, 255, 0.03);border:1px solid rgba(255, 255, 255, 0.08);border-radius:12px;color:#8b949e;font-size:18px;text-decoration:none;transition:all 0.3s ease;cursor:pointer;';
            btn.innerHTML = '<i class="fa-solid ' + iconClass + '"></i>';
            btn.title = t(titleKey, titleFallback);
            btn.onmouseover = function() { this.style.color = '#00d4ff'; this.style.borderColor = 'rgba(0, 212, 255, 0.4)'; this.style.background = 'rgba(0, 212, 255, 0.05)'; this.style.transform = 'translateY(-2px)'; this.style.boxShadow = '0 8px 16px rgba(0, 212, 255, 0.15)'; };
            btn.onmouseout = function() { this.style.color = '#8b949e'; this.style.borderColor = 'rgba(255, 255, 255, 0.08)'; this.style.background = 'rgba(255, 255, 255, 0.03)'; this.style.transform = 'translateY(0)'; this.style.boxShadow = 'none'; };
            iconButtons.appendChild(btn);
            return btn;
        }

        const discordBtn = createIconButton('nk-fixes-discord', 'fa-brands fa-discord', 'menu.discord', 'Discord');
        const settingsBtn = createIconButton('nk-fixes-settings', 'fa-gear', 'menu.settings', 'Settings');
        const closeIconBtn = createIconButton('nk-fixes-close', 'fa-xmark', 'settings.close', 'Close');

        const body = document.createElement('div');
        body.className = 'newkey-scroll';
        body.style.cssText = 'flex:1 1 auto;overflow-y:auto;padding:24px;border:1px solid rgba(255,255,255,0.05);border-radius:16px;background:rgba(5, 8, 15, 0.4);box-shadow:inset 0 4px 20px rgba(0,0,0,0.5);';

        try {
            const bannerImg = document.querySelector('.game_header_image_full');
            if (bannerImg && bannerImg.src) {
                body.style.background = `linear-gradient(to bottom, rgba(5, 8, 15, 0.85), #05080f 80%), url('${bannerImg.src}') no-repeat top center`;
                body.style.backgroundSize = 'cover';
            }
        } catch(_) {}

        const gameHeader = document.createElement('div');
        gameHeader.style.cssText = 'display:flex;align-items:center;justify-content:center;gap:16px;margin-bottom:24px;';

        const gameIcon = document.createElement('img');
        gameIcon.style.cssText = 'width:40px;height:40px;border-radius:8px;object-fit:cover;display:none;box-shadow:0 4px 12px rgba(0,0,0,0.5); border: 1px solid rgba(255,255,255,0.1);';
        try {
            const iconImg = document.querySelector('.apphub_AppIcon img');
            if (iconImg && iconImg.src) {
                gameIcon.src = iconImg.src;
                gameIcon.style.display = 'block';
            }
        } catch(_) {}

        const gameName = document.createElement('div');
        gameName.style.cssText = 'font-size:24px;color:#fff;font-weight:700;text-align:center;letter-spacing:0.5px;text-shadow: 0 2px 4px rgba(0,0,0,0.8);';
        gameName.textContent = data.gameName || nk('Unknown Game');

        const contentContainer = document.createElement('div');
        contentContainer.style.position = 'relative';
        contentContainer.style.zIndex = '1';

        const columnsContainer = document.createElement('div');
        columnsContainer.style.cssText = 'display:flex;gap:20px;';

        const leftColumn = document.createElement('div');
        leftColumn.style.cssText = 'flex:1;display:flex;flex-direction:column;gap:20px;';

        const rightColumn = document.createElement('div');
        rightColumn.style.cssText = 'flex:1;display:flex;flex-direction:column;gap:20px;';

        function createFixButton(label, text, icon, isSuccess, onClick) {
            const section = document.createElement('div');
            section.style.cssText = 'width:100%;text-align:left;background:rgba(22, 27, 34, 0.6); border: 1px solid rgba(255,255,255,0.05); border-radius: 16px; padding: 16px; backdrop-filter:blur(4px); box-shadow: 0 4px 16px rgba(0,0,0,0.2);';

            const sectionLabel = document.createElement('div');
            sectionLabel.style.cssText = 'font-size:12px;color:#8b949e;margin-bottom:12px;font-weight:700;text-transform:uppercase;letter-spacing:1px;';
            sectionLabel.textContent = label;

            const btn = document.createElement('a');
            btn.href = '#';
            btn.style.cssText = 'display:flex;align-items:center;justify-content:center;gap:10px;width:100%;box-sizing:border-box;padding:14px 24px;background:rgba(0, 212, 255, 0.05);border:1px solid rgba(0, 212, 255, 0.2);border-radius:12px;color:#00d4ff;font-size:15px;font-weight:600;text-decoration:none;transition:all 0.3s cubic-bezier(0.25, 1, 0.5, 1);cursor:pointer;';
            btn.innerHTML = '<i class="fa-solid ' + icon + '" style="font-size:16px;"></i><span>' + text + '</span>';

            if (isSuccess) {
                btn.style.background = 'rgba(16, 185, 129, 0.1)';
                btn.style.borderColor = 'rgba(16, 185, 129, 0.4)';
                btn.style.color = '#10b981';
                btn.onmouseover = function() { this.style.background = 'rgba(16, 185, 129, 0.2)'; this.style.transform = 'translateY(-2px)'; this.style.boxShadow = '0 8px 20px rgba(16, 185, 129, 0.2)'; this.style.borderColor = '#10b981'; };
                btn.onmouseout = function() { this.style.background = 'rgba(16, 185, 129, 0.1)'; this.style.transform = 'translateY(0)'; this.style.boxShadow = 'none'; this.style.borderColor = 'rgba(16, 185, 129, 0.4)'; };
            } else if (isSuccess === false) {
                btn.style.background = 'rgba(255, 255, 255, 0.02)';
                btn.style.borderColor = 'rgba(255, 255, 255, 0.05)';
                btn.style.color = '#8b949e';
                btn.style.cursor = 'not-allowed';
            } else {
                btn.onmouseover = function() { this.style.background = 'rgba(0, 212, 255, 0.15)'; this.style.transform = 'translateY(-2px)'; this.style.boxShadow = '0 8px 20px rgba(0, 212, 255, 0.2)'; this.style.borderColor = 'rgba(0, 212, 255, 0.5)'; };
                btn.onmouseout = function() { this.style.background = 'rgba(0, 212, 255, 0.05)'; this.style.transform = 'translateY(0)'; this.style.boxShadow = 'none'; this.style.borderColor = 'rgba(0, 212, 255, 0.2)'; };
            }

            btn.onclick = onClick;

            section.appendChild(sectionLabel);
            section.appendChild(btn);
            return section;
        }

        const genericStatus = data.genericFix.status;
        const genericSection = createFixButton(
            nk('Generic Fix'),
            genericStatus === 200 ? nk('Apply') : nk('No generic fix'),
            genericStatus === 200 ? 'fa-check' : 'fa-circle-xmark',
            genericStatus === 200 ? true : false,
            function(e) {
                e.preventDefault();
                if (genericStatus === 200 && isGameInstalled) {
                    const genericUrl = 'https://files.luatools.work/GameBypasses/' + data.appid + '.zip';
                    applyFix(data.appid, genericUrl, nk('Generic Fix'), data.gameName, overlay);
                }
            }
        );
        leftColumn.appendChild(genericSection);

        if (!isGameInstalled) {
            genericSection.querySelector('a').style.opacity = '0.5';
            genericSection.querySelector('a').style.cursor = 'not-allowed';
        }

        const onlineStatus = data.onlineFix.status;
        const onlineSection = createFixButton(
            nk('Online Fix'),
            onlineStatus === 200 ? nk('Apply') : nk('No online-fix'),
            onlineStatus === 200 ? 'fa-check' : 'fa-circle-xmark',
            onlineStatus === 200 ? true : false,
            function(e) {
                e.preventDefault();
                if (onlineStatus === 200 && isGameInstalled) {
                    const onlineUrl = data.onlineFix.url || ('https://files.luatools.work/OnlineFix1/' + data.appid + '.zip');
                    applyFix(data.appid, onlineUrl, nk('Online Fix'), data.gameName, overlay);
                }
            }
        );
        leftColumn.appendChild(onlineSection);

        if (!isGameInstalled) {
            onlineSection.querySelector('a').style.opacity = '0.5';
            onlineSection.querySelector('a').style.cursor = 'not-allowed';
        }

        const aioSection = createFixButton(
            nk('All-In-One Fixes'),
            nk('Online Fix (Unsteam)'),
            'fa-globe',
            null, 
            function(e) {
                e.preventDefault();
                if (isGameInstalled) {
                    const downloadUrl = 'https://github.com/madoiscool/lt_api_links/releases/download/unsteam/Win64.zip';
                    applyFix(data.appid, downloadUrl, nk('Online Fix (Unsteam)'), data.gameName, overlay);
                }
            }
        );
        rightColumn.appendChild(aioSection);
        if (!isGameInstalled) {
            aioSection.querySelector('a').style.opacity = '0.5';
            aioSection.querySelector('a').style.cursor = 'not-allowed';
        }

        const unfixSection = createFixButton(
            nk('Manage Game'),
            nk('Un-Fix (verify game)'),
            'fa-trash',
            null, 
            function(e) {
                e.preventDefault();
                if (isGameInstalled) {
                    try { overlay.remove(); } catch(_) {}
                    showNewKeyConfirm('NewKey', nk('Are you sure you want to un-fix? This will remove fix files and verify game files.'),
                        function() { startUnfix(data.appid); },
                        function() { showFixesResultsPopup(data, isGameInstalled); }
                    );
                }
            }
        );
        // Style unfix button specifically
        const unfixBtn = unfixSection.querySelector('a');
        unfixBtn.style.color = '#f43f5e';
        unfixBtn.style.background = 'rgba(244, 63, 94, 0.05)';
        unfixBtn.style.borderColor = 'rgba(244, 63, 94, 0.2)';
        unfixBtn.onmouseover = function() { this.style.background = 'rgba(244, 63, 94, 0.15)'; this.style.transform = 'translateY(-2px)'; this.style.boxShadow = '0 8px 20px rgba(244, 63, 94, 0.2)'; this.style.borderColor = 'rgba(244, 63, 94, 0.5)'; };
        unfixBtn.onmouseout = function() { this.style.background = 'rgba(244, 63, 94, 0.05)'; this.style.transform = 'translateY(0)'; this.style.boxShadow = 'none'; this.style.borderColor = 'rgba(244, 63, 94, 0.2)'; };

        rightColumn.appendChild(unfixSection);
        if (!isGameInstalled) {
            unfixBtn.style.opacity = '0.5';
            unfixBtn.style.cursor = 'not-allowed';
            unfixBtn.onmouseover = null;
            unfixBtn.onmouseout = null;
        }

        const creditMsg = document.createElement('div');
        creditMsg.style.cssText = 'margin-top:24px;text-align:center;font-size:13px;color:#8b949e;';
        const creditTemplate = nk('Only possible thanks to {name} 💜');
        creditMsg.innerHTML = creditTemplate.replace('{name}', '<a href="#" id="nk-shayenvi-link" style="color:#00d4ff;text-decoration:none;font-weight:600;transition: color 0.2s;">ZEED</a>');
        
        setTimeout(function(){
            const shayenviLink = overlay.querySelector('#nk-shayenvi-link');
            if (shayenviLink) {
                shayenviLink.onmouseover = () => shayenviLink.style.color = '#007bf5';
                shayenviLink.onmouseout = () => shayenviLink.style.color = '#00d4ff';
                shayenviLink.addEventListener('click', function(e){
                    e.preventDefault();
                    try {
                        Millennium.callServerMethod('newkey', 'OpenExternalUrl', { url: 'https://guns.lol/zeed_dev', contentScriptQuery: '' });
                    } catch(_) {}
                });
            }
        }, 0);

        gameHeader.appendChild(gameIcon);
        gameHeader.appendChild(gameName);
        contentContainer.appendChild(gameHeader);

        if (!isGameInstalled) {
            const notInstalledWarning = document.createElement('div');
            notInstalledWarning.style.cssText = 'margin-bottom: 24px; padding: 16px; background: rgba(245, 158, 11, 0.1); border: 1px solid rgba(245, 158, 11, 0.3); border-radius: 12px; color: #f59e0b; font-size: 14px; font-weight:500; text-align: center; box-shadow: 0 4px 12px rgba(245, 158, 11, 0.1);';
            notInstalledWarning.innerHTML = '<i class="fa-solid fa-circle-info" style="margin-right: 8px;"></i>' + t('menu.error.notInstalled', 'Game is not installed');
            contentContainer.appendChild(notInstalledWarning);
        }

        columnsContainer.appendChild(leftColumn);
        columnsContainer.appendChild(rightColumn);
        contentContainer.appendChild(columnsContainer);
        contentContainer.appendChild(creditMsg);
        body.appendChild(contentContainer);

        header.appendChild(title);
        header.appendChild(iconButtons);

        const btnRow = document.createElement('div');
        btnRow.style.cssText = 'flex:0 0 auto;margin-top:24px;display:flex;gap:12px;justify-content:space-between;align-items:center;';

        const rightButtons = document.createElement('div');
        rightButtons.style.cssText = 'display:flex;gap:12px;';
        const gameFolderBtn = document.createElement('a');
        gameFolderBtn.className = 'newkey-btn primary';
        gameFolderBtn.innerHTML = `<span><i class="fa-solid fa-folder" style="margin-right: 8px;"></i>${nk('Game folder')}</span>`;
        gameFolderBtn.href = '#';
        gameFolderBtn.onclick = function(e){ 
            e.preventDefault(); 
            if (window.__NewKeyGameInstallPath) {
                try {
                    Millennium.callServerMethod('newkey', 'OpenGameFolder', { path: window.__NewKeyGameInstallPath, contentScriptQuery: '' });
                } catch(err) { backendLog('NewKey: Failed to open game folder: ' + err); }
            }
        };
        rightButtons.appendChild(gameFolderBtn);

        const backBtn = document.createElement('a');
        backBtn.className = 'newkey-btn';
        backBtn.innerHTML = '<span><i class="fa-solid fa-arrow-left"></i></span>';
        backBtn.href = '#';
        backBtn.onclick = function(e){
            e.preventDefault();
            try { overlay.remove(); } catch(_) {}
            showSettingsPopup();
        };
        btnRow.appendChild(backBtn);
        btnRow.appendChild(rightButtons);

        modal.appendChild(header);
        modal.appendChild(body);
        modal.appendChild(btnRow);  
        overlay.appendChild(modal);
        document.body.appendChild(overlay);

        closeIconBtn.onclick = function(e) { e.preventDefault(); overlay.remove(); };
        discordBtn.onclick = function(e) {
            e.preventDefault();
            try { overlay.remove(); } catch(_) {}
            const url = 'https://discord.gg/nsCGfP22';
            try { Millennium.callServerMethod('newkey', 'OpenExternalUrl', { url, contentScriptQuery: '' }); } catch(_) {}
        };
        settingsBtn.onclick = function(e) {
            e.preventDefault();
            try { overlay.remove(); } catch(_) {}
            showSettingsManagerPopup(false, function() { showFixesResultsPopup(data, isGameInstalled); });
        };

        function startUnfix(appid) {
            try {
                Millennium.callServerMethod('newkey', 'UnFixGame', { appid: appid, installPath: window.__NewKeyGameInstallPath, contentScriptQuery: '' }).then(function(res){
                    const payload = typeof res === 'string' ? JSON.parse(res) : res;
                    if (payload && payload.success) {
                        showUnfixProgress(appid);
                    } else {
                        const errorKey = (payload && payload.error) ? String(payload.error) : '';
                        const errorMsg = (errorKey && (errorKey.startsWith('menu.error.') || errorKey.startsWith('common.'))) ? t(errorKey) : (errorKey || nk('Failed to start un-fix'));
                        ShowNewKeyAlert('NewKey', errorMsg);
                    }
                }).catch(function(){
                    const msg = nk('Error starting un-fix');
                    ShowNewKeyAlert('NewKey', msg);
                });
            } catch(err) { backendLog('NewKey: Un-Fix start error: ' + err); }
        }
    }

    function showFixesLoadingPopupAndCheck(appid) {
        if (document.querySelector('.newkey-loading-fixes-overlay')) return;
        try { const d = document.querySelector('.newkey-overlay'); if (d) d.remove(); } catch(_) {}
        try { const s = document.querySelector('.newkey-settings-overlay'); if (s) s.remove(); } catch(_) {}
        try { const f = document.querySelector('.newkey-fixes-overlay'); if (f) f.remove(); } catch(_) {}

        ensureNewKeyStyles();
        const overlay = document.createElement('div');
        overlay.className = 'newkey-loading-fixes-overlay';
        overlay.style.cssText = 'position:fixed;inset:0;background:rgba(5, 8, 15, 0.85);backdrop-filter:blur(16px);z-index:99999;display:flex;align-items:center;justify-content:center;animation:fadeIn 0.2s ease-out;';

        const modal = document.createElement('div');
        modal.style.cssText = 'background:linear-gradient(145deg, #0d1117 0%, #161b22 100%);color:#fff;border:1px solid rgba(255, 255, 255, 0.08);border-radius:16px;min-width:400px;max-width:560px;padding:32px;box-shadow:0 24px 48px rgba(0,0,0,0.8), 0 0 0 1px rgba(0, 212, 255, 0.1);animation:slideUp 0.3s cubic-bezier(0.25, 1, 0.5, 1);';

        const title = document.createElement('div');
        title.style.cssText = 'font-size:24px;font-weight:800;letter-spacing:0.5px;margin-bottom:16px;background:linear-gradient(135deg, #00d4ff 0%, #007bf5 100%);-webkit-background-clip:text;-webkit-text-fill-color:transparent;text-shadow:0 4px 12px rgba(0, 212, 255, 0.3);';
        title.textContent = nk('Loading fixes...');

        const body = document.createElement('div');
        body.style.cssText = 'font-size:15px;line-height:1.6;margin-bottom:20px;color:#e6edf3;';
        body.textContent = nk('Checking availability…');

        const progressWrap = document.createElement('div');
        progressWrap.style.cssText = 'background:rgba(255,255,255,0.05);height:12px;border-radius:6px;overflow:hidden;position:relative;border:1px solid rgba(255,255,255,0.1);';
        const progressBar = document.createElement('div');
        progressBar.style.cssText = 'height:100%;width:0%;background:linear-gradient(90deg, #00d4ff 0%, #007bf5 100%);transition:width 0.2s linear;box-shadow:0 0 12px rgba(0, 212, 255, 0.6);';
        progressWrap.appendChild(progressBar);

        modal.appendChild(title);
        modal.appendChild(body);
        modal.appendChild(progressWrap);
        overlay.appendChild(modal);
        document.body.appendChild(overlay);

        let progress = 0;
        const progressInterval = setInterval(function() {
            if (progress < 95) {
                progress += Math.random() * 5;
                progressBar.style.width = Math.min(progress, 95) + '%';
            }
        }, 200);

        Millennium.callServerMethod('newkey', 'CheckForFixes', { appid, contentScriptQuery: '' }).then(function(res){
            const payload = typeof res === 'string' ? JSON.parse(res) : res;
            if (payload && payload.success) {
                const isGameInstalled = window.__NewKeyGameIsInstalled === true;
                showFixesResultsPopup(payload, isGameInstalled);
            } else {
                const errText = (payload && payload.error) ? String(payload.error) : nk('Failed to check for fixes.');
                ShowNewKeyAlert('NewKey', errText);
            }
        }).catch(function() {
            const msg = nk('Error checking for fixes');
            ShowNewKeyAlert('NewKey', msg);
        }).finally(function() {
            clearInterval(progressInterval);
            progressBar.style.width = '100%';
            setTimeout(function() {
                try {
                    const l = document.querySelector('.newkey-loading-fixes-overlay');
                    if (l) l.remove();
                } catch(_) {}
            }, 300);
        });
    }

    function applyFix(appid, downloadUrl, fixType, gameName, resultsOverlay) {
        try {
            if (resultsOverlay) {
                resultsOverlay.remove();
            }
            
            if (!window.__NewKeyGameInstallPath) {
                const msg = nk('Game install path not found');
                ShowNewKeyAlert('NewKey', msg);
                return;
            }
            
            backendLog('NewKey: Applying fix ' + fixType + ' for appid ' + appid);
            
            Millennium.callServerMethod('newkey', 'ApplyGameFix', { 
                appid: appid, 
                downloadUrl: downloadUrl, 
                installPath: window.__NewKeyGameInstallPath,
                fixType: fixType,
                gameName: gameName || '',
                contentScriptQuery: '' 
            }).then(function(res){
                try {
                    const payload = typeof res === 'string' ? JSON.parse(res) : res;
                    if (payload && payload.success) {
                        showFixDownloadProgress(appid, fixType);
                    } else {
                        const errorKey = (payload && payload.error) ? String(payload.error) : '';
                        const errorMsg = (errorKey && (errorKey.startsWith('menu.error.') || errorKey.startsWith('common.'))) ? t(errorKey) : (errorKey || nk('Failed to start fix download'));
                        ShowNewKeyAlert('NewKey', errorMsg);
                    }
                } catch(err) {
                    backendLog('NewKey: ApplyGameFix response error: ' + err);
                    const msg = nk('Error applying fix');
                    ShowNewKeyAlert('NewKey', msg);
                }
            }).catch(function(err){
                backendLog('NewKey: ApplyGameFix error: ' + err);
                const msg = nk('Error applying fix');
                ShowNewKeyAlert('NewKey', msg);
            });
        } catch(err) {
            backendLog('NewKey: applyFix error: ' + err);
        }
    }

    function showFixDownloadProgress(appid, fixType) {
        if (document.querySelector('.newkey-overlay')) return;

        ensureNewKeyStyles();
        const overlay = document.createElement('div');
        overlay.className = 'newkey-overlay';
        overlay.style.cssText = 'position:fixed;inset:0;background:rgba(5, 8, 15, 0.85);backdrop-filter:blur(16px);z-index:99999;display:flex;align-items:center;justify-content:center;animation:fadeIn 0.2s ease-out;';

        const modal = document.createElement('div');
        modal.style.cssText = 'background:linear-gradient(145deg, #0d1117 0%, #161b22 100%);color:#fff;border:1px solid rgba(255, 255, 255, 0.08);border-radius:16px;min-width:400px;max-width:560px;padding:32px;box-shadow:0 24px 48px rgba(0,0,0,0.8), 0 0 0 1px rgba(0, 212, 255, 0.1);animation:slideUp 0.3s cubic-bezier(0.25, 1, 0.5, 1);';

        const title = document.createElement('div');
        title.style.cssText = 'font-size:24px;font-weight:800;letter-spacing:0.5px;margin-bottom:16px;background:linear-gradient(135deg, #00d4ff 0%, #007bf5 100%);-webkit-background-clip:text;-webkit-text-fill-color:transparent;text-shadow:0 4px 12px rgba(0, 212, 255, 0.3);';
        title.textContent = nk('Applying {fix}').replace('{fix}', fixType);

        const body = document.createElement('div');
        body.style.cssText = 'font-size:15px;line-height:1.6;margin-bottom:24px;color:#e6edf3;';
        body.innerHTML = '<div id="nk-fix-progress-msg">' + nk('Downloading...') + '</div>';

        const btnRow = document.createElement('div');
        btnRow.className = 'nk-fix-btn-row';
        btnRow.style.cssText = 'margin-top:24px;display:flex;gap:12px;justify-content:center;';

        const hideBtn = document.createElement('a');
        hideBtn.href = '#';
        hideBtn.className = 'newkey-btn';
        hideBtn.style.flex = '1';
        hideBtn.innerHTML = `<span>${nk('Hide')}</span>`;
        hideBtn.onclick = function(e){ e.preventDefault(); overlay.remove(); };
        btnRow.appendChild(hideBtn);

        const cancelBtn = document.createElement('a');
        cancelBtn.href = '#';
        cancelBtn.className = 'newkey-btn primary';
        cancelBtn.style.flex = '1';
        cancelBtn.innerHTML = `<span>${nk('Cancel')}</span>`;
        cancelBtn.onclick = function(e){
            e.preventDefault();
            if (cancelBtn.dataset.pending === '1') return;
            cancelBtn.dataset.pending = '1';
            const span = cancelBtn.querySelector('span');
            if (span) span.textContent = nk('Cancelling...');
            const msgEl = document.getElementById('nk-fix-progress-msg');
            if (msgEl) msgEl.textContent = nk('Cancelling...');
            Millennium.callServerMethod('newkey', 'CancelApplyFix', { appid: appid, contentScriptQuery: '' }).then(function(res){
                try {
                    const payload = typeof res === 'string' ? JSON.parse(res) : res;
                    if (!payload || payload.success !== true) {
                        throw new Error((payload && payload.error) || nk('Cancellation failed'));
                    }
                } catch(err) {
                    cancelBtn.dataset.pending = '0';
                    if (span) span.textContent = nk('Cancel');
                    const msgEl2 = document.getElementById('nk-fix-progress-msg');
                    if (msgEl2 && msgEl2.dataset.last) msgEl2.textContent = msgEl2.dataset.last;
                    backendLog('NewKey: CancelApplyFix response error: ' + err);
                    const msg = nk('Failed to cancel fix download');
                    ShowNewKeyAlert('NewKey', msg);
                }
            }).catch(function(err){
                cancelBtn.dataset.pending = '0';
                const span2 = cancelBtn.querySelector('span');
                if (span2) span2.textContent = nk('Cancel');
                const msgEl2 = document.getElementById('nk-fix-progress-msg');
                if (msgEl2 && msgEl2.dataset.last) msgEl2.textContent = msgEl2.dataset.last;
                backendLog('NewKey: CancelApplyFix error: ' + err);
                const msg = nk('Failed to cancel fix download');
                ShowNewKeyAlert('NewKey', msg);
            });
        };
        btnRow.appendChild(cancelBtn);

        modal.appendChild(title);
        modal.appendChild(body);
        modal.appendChild(btnRow);
        overlay.appendChild(modal);
        document.body.appendChild(overlay);

        pollFixProgress(appid, fixType);
    }

    function replaceFixButtonsWithClose(overlayEl) {
        if (!overlayEl) return;
        const btnRow = overlayEl.querySelector('.nk-fix-btn-row');
        if (!btnRow) return;
        btnRow.innerHTML = '';
        btnRow.style.cssText = 'margin-top:24px;display:flex;justify-content:flex-end;';
        const closeBtn = document.createElement('a');
        closeBtn.href = '#';
        closeBtn.className = 'newkey-btn primary';
        closeBtn.style.minWidth = '140px';
        closeBtn.innerHTML = `<span>${nk('Close')}</span>`;
        closeBtn.onclick = function(e){ e.preventDefault(); overlayEl.remove(); };
        btnRow.appendChild(closeBtn);
    }

    function pollFixProgress(appid, fixType) {
        const poll = function() {
            try {
                const overlayEl = document.querySelector('.newkey-overlay');
                if (!overlayEl) return; 
                
                Millennium.callServerMethod('newkey', 'GetApplyFixStatus', { appid: appid, contentScriptQuery: '' }).then(function(res){
                    try {
                        const payload = typeof res === 'string' ? JSON.parse(res) : res;
                        if (payload && payload.success && payload.state) {
                            const state = payload.state;
                            const msgEl = document.getElementById('nk-fix-progress-msg');
                            
                            if (state.status === 'downloading') {
                                const pct = state.totalBytes > 0 ? Math.floor((state.bytesRead / state.totalBytes) * 100) : 0;
                                if (msgEl) { msgEl.textContent = nk('Downloading: {percent}%').replace('{percent}', pct); msgEl.dataset.last = msgEl.textContent; }
                                setTimeout(poll, 500);
                            } else if (state.status === 'extracting') {
                                if (msgEl) { msgEl.textContent = nk('Extracting to game folder...'); msgEl.dataset.last = msgEl.textContent; }
                                setTimeout(poll, 500);
                            } else if (state.status === 'cancelled') {
                                if (msgEl) msgEl.textContent = nk('Cancelled: {reason}').replace('{reason}', state.error || nk('Cancelled by user'));
                                replaceFixButtonsWithClose(overlayEl);
                                return;
                            } else if (state.status === 'done') {
                                if (msgEl) msgEl.textContent = nk('{fix} applied successfully!').replace('{fix}', fixType);
                                replaceFixButtonsWithClose(overlayEl);
                                return; 
                            } else if (state.status === 'failed') {
                                if (msgEl) msgEl.textContent = nk('Failed: {error}').replace('{error}', state.error || nk('Unknown error'));
                                replaceFixButtonsWithClose(overlayEl);
                                return; 
                            } else {
                                setTimeout(poll, 500);
                            }
                        }
                    } catch(err) {
                        backendLog('NewKey: GetApplyFixStatus error: ' + err);
                    }
                });
            } catch(err) {
                backendLog('NewKey: pollFixProgress error: ' + err);
            }
        };
        setTimeout(poll, 500);
    }

    function showUnfixProgress(appid) {
        try { const old = document.querySelector('.newkey-unfix-overlay'); if (old) old.remove(); } catch(_) {}

        ensureNewKeyStyles();
        const overlay = document.createElement('div');
        overlay.className = 'newkey-unfix-overlay';
        overlay.style.cssText = 'position:fixed;inset:0;background:rgba(5, 8, 15, 0.85);backdrop-filter:blur(16px);z-index:99999;display:flex;align-items:center;justify-content:center;animation:fadeIn 0.2s ease-out;';

        const modal = document.createElement('div');
        modal.style.cssText = 'background:linear-gradient(145deg, #0d1117 0%, #161b22 100%);color:#fff;border:1px solid rgba(255, 255, 255, 0.08);border-radius:16px;min-width:400px;max-width:560px;padding:32px;box-shadow:0 24px 48px rgba(0,0,0,0.8), 0 0 0 1px rgba(0, 212, 255, 0.1);animation:slideUp 0.3s cubic-bezier(0.25, 1, 0.5, 1);';

        const title = document.createElement('div');
        title.style.cssText = 'font-size:24px;font-weight:800;letter-spacing:0.5px;margin-bottom:16px;background:linear-gradient(135deg, #00d4ff 0%, #007bf5 100%);-webkit-background-clip:text;-webkit-text-fill-color:transparent;text-shadow:0 4px 12px rgba(0, 212, 255, 0.3);';
        title.textContent = nk('Un-Fixing game');

        const body = document.createElement('div');
        body.style.cssText = 'font-size:15px;line-height:1.6;margin-bottom:24px;color:#e6edf3;';
        body.innerHTML = '<div id="nk-unfix-progress-msg">' + nk('Removing fix files...') + '</div>';

        const btnRow = document.createElement('div');
        btnRow.style.cssText = 'margin-top:24px;display:flex;justify-content:center;';
        const hideBtn = document.createElement('a');
        hideBtn.href = '#';
        hideBtn.className = 'newkey-btn primary';
        hideBtn.style.minWidth = '140px';
        hideBtn.innerHTML = `<span>${nk('Hide')}</span>`;
        hideBtn.onclick = function(e){ e.preventDefault(); overlay.remove(); };
        btnRow.appendChild(hideBtn);

        modal.appendChild(title);
        modal.appendChild(body);
        modal.appendChild(btnRow);
        overlay.appendChild(modal);
        document.body.appendChild(overlay);

        pollUnfixProgress(appid);
    }

    function pollUnfixProgress(appid) {
        const poll = function() {
            try {
                const overlayEl = document.querySelector('.newkey-unfix-overlay');
                if (!overlayEl) return; 
                
                Millennium.callServerMethod('newkey', 'GetUnfixStatus', { appid: appid, contentScriptQuery: '' }).then(function(res){
                    try {
                        const payload = typeof res === 'string' ? JSON.parse(res) : res;
                        if (payload && payload.success && payload.state) {
                            const state = payload.state;
                            const msgEl = document.getElementById('nk-unfix-progress-msg');
                            
                            if (state.status === 'removing') {
                                if (msgEl) msgEl.textContent = state.progress || nk('Removing fix files...');
                                setTimeout(poll, 500);
                            } else if (state.status === 'done') {
                                const filesRemoved = state.filesRemoved || 0;
                                if (msgEl) msgEl.textContent = nk('Removed {count} files. Running Steam verification...').replace('{count}', filesRemoved);
                                try {
                                    const btnRow = overlayEl.querySelector('div[style*="justify-content:center"]');
                                    if (btnRow) {
                                        btnRow.innerHTML = '';
                                        const closeBtn = document.createElement('a');
                                        closeBtn.href = '#';
                                        closeBtn.className = 'newkey-btn primary';
                                        closeBtn.style.minWidth = '140px';
                                        closeBtn.innerHTML = `<span>${nk('Close')}</span>`;
                                        closeBtn.onclick = function(e){ e.preventDefault(); overlayEl.remove(); };
                                        btnRow.appendChild(closeBtn);
                                    }
                                } catch(_) {}
                                
                                setTimeout(function(){
                                    try {
                                        const verifyUrl = 'steam://validate/' + appid;
                                        window.location.href = verifyUrl;
                                        backendLog('NewKey: Running verify for appid ' + appid);
                                    } catch(_) {}
                                }, 1000);
                                
                                return; 
                            } else if (state.status === 'failed') {
                                if (msgEl) msgEl.textContent = nk('Failed: {error}').replace('{error}', state.error || nk('Unknown error'));
                                try {
                                    const btnRow = overlayEl.querySelector('div[style*="justify-content:center"]');
                                    if (btnRow) {
                                        btnRow.innerHTML = '';
                                        const closeBtn = document.createElement('a');
                                        closeBtn.href = '#';
                                        closeBtn.className = 'newkey-btn primary';
                                        closeBtn.style.minWidth = '140px';
                                        closeBtn.innerHTML = `<span>${nk('Close')}</span>`;
                                        closeBtn.onclick = function(e){ e.preventDefault(); overlayEl.remove(); };
                                        btnRow.appendChild(closeBtn);
                                    }
                                } catch(_) {}
                                return; 
                            } else {
                                setTimeout(poll, 500);
                            }
                        }
                    } catch(err) {
                        backendLog('NewKey: GetUnfixStatus error: ' + err);
                    }
                });
            } catch(err) {
                backendLog('NewKey: pollUnfixProgress error: ' + err);
            }
        };
        setTimeout(poll, 500);
    }

    function fetchSettingsConfig(forceRefresh) {
        try {
            if (!forceRefresh && window.__NewKeySettings && Array.isArray(window.__NewKeySettings.schema)) {
                return Promise.resolve(window.__NewKeySettings);
            }
        } catch(_) {}

        if (typeof Millennium === 'undefined' || typeof Millennium.callServerMethod !== 'function') {
            return Promise.reject(new Error(nk('NewKey backend unavailable')));
        }

        return Millennium.callServerMethod('newkey', 'GetSettingsConfig', { contentScriptQuery: '' }).then(function(res){
            const payload = typeof res === 'string' ? JSON.parse(res) : res;
            if (!payload || payload.success !== true) {
                const errorMsg = (payload && payload.error) ? String(payload.error) : t('settings.error', 'Failed to load settings.');
                throw new Error(errorMsg);
            }
            const config = {
                schemaVersion: payload.schemaVersion || 0,
                schema: Array.isArray(payload.schema) ? payload.schema : [],
                values: (payload && payload.values && typeof payload.values === 'object') ? payload.values : {},
                language: payload && payload.language ? String(payload.language) : 'en',
                locales: Array.isArray(payload && payload.locales) ? payload.locales : [],
                translations: (payload && payload.translations && typeof payload.translations === 'object') ? payload.translations : {},
                lastFetched: Date.now()
            };
            applyTranslationBundle({
                language: config.language,
                locales: config.locales,
                strings: config.translations
            });
            window.__NewKeySettings = config;
            return config;
        });
    }

    function initialiseSettingsDraft(config) {
        const values = JSON.parse(JSON.stringify((config && config.values) || {}));
        if (!config || !Array.isArray(config.schema)) {
            return values;
        }
        for (let i = 0; i < config.schema.length; i++) {
            const group = config.schema[i];
            if (!group || !group.key) continue;
            if (typeof values[group.key] !== 'object' || values[group.key] === null || Array.isArray(values[group.key])) {
                values[group.key] = {};
            }
            const options = Array.isArray(group.options) ? group.options : [];
            for (let j = 0; j < options.length; j++) {
                const option = options[j];
                if (!option || !option.key) continue;
                if (typeof values[group.key][option.key] === 'undefined') {
                    values[group.key][option.key] = option.default;
                }
            }
        }
        return values;
    }

    function showSettingsManagerPopup(forceRefresh, onBack) {
        if (document.querySelector('.newkey-settings-manager-overlay')) return;

        try { const mainOverlay = document.querySelector('.newkey-settings-overlay'); if (mainOverlay) mainOverlay.remove(); } catch(_) {}

        ensureNewKeyStyles();
        ensureFontAwesome();

        const overlay = document.createElement('div');
        overlay.className = 'newkey-settings-manager-overlay';
        overlay.style.cssText = 'position:fixed;inset:0;background:rgba(5, 8, 15, 0.85);backdrop-filter:blur(16px);z-index:100000;display:flex;align-items:center;justify-content:center;animation:fadeIn 0.2s ease-out;';

        const modal = document.createElement('div');
        modal.style.cssText = 'position:relative;background:linear-gradient(145deg, #0d1117 0%, #161b22 100%);color:#fff;border:1px solid rgba(255, 255, 255, 0.08);border-radius:16px;min-width:650px;max-width:750px;max-height:85vh;display:flex;flex-direction:column;box-shadow:0 24px 48px rgba(0,0,0,0.8), 0 0 0 1px rgba(0, 212, 255, 0.1);animation:slideUp 0.3s cubic-bezier(0.25, 1, 0.5, 1);overflow:hidden;';

        const header = document.createElement('div');
        header.style.cssText = 'display:flex;justify-content:space-between;align-items:center;margin-bottom:20px;padding:32px 32px 16px;border-bottom:1px solid rgba(255, 255, 255, 0.05);';

        const title = document.createElement('div');
        title.style.cssText = 'font-size:24px;font-weight:800;letter-spacing:0.5px;background:linear-gradient(135deg, #00d4ff 0%, #007bf5 100%);-webkit-background-clip:text;-webkit-text-fill-color:transparent;text-shadow:0 4px 12px rgba(0, 212, 255, 0.3);';
        title.textContent = t('settings.title', 'NewKey · Settings');

        const iconButtons = document.createElement('div');
        iconButtons.style.cssText = 'display:flex;gap:12px;';

        const discordIconBtn = document.createElement('a');
        discordIconBtn.href = '#';
        discordIconBtn.style.cssText = 'display:flex;align-items:center;justify-content:center;width:40px;height:40px;background:rgba(255, 255, 255, 0.03);border:1px solid rgba(255, 255, 255, 0.08);border-radius:12px;color:#8b949e;font-size:18px;text-decoration:none;transition:all 0.3s ease;cursor:pointer;';
        discordIconBtn.innerHTML = '<i class="fa-brands fa-discord"></i>';
        discordIconBtn.title = t('menu.discord', 'Discord');
        discordIconBtn.onmouseover = function() { this.style.color = '#00d4ff'; this.style.borderColor = 'rgba(0, 212, 255, 0.4)'; this.style.background = 'rgba(0, 212, 255, 0.05)'; this.style.transform = 'translateY(-2px)'; this.style.boxShadow = '0 8px 16px rgba(0, 212, 255, 0.15)'; };
        discordIconBtn.onmouseout = function() { this.style.color = '#8b949e'; this.style.borderColor = 'rgba(255, 255, 255, 0.08)'; this.style.background = 'rgba(255, 255, 255, 0.03)'; this.style.transform = 'translateY(0)'; this.style.boxShadow = 'none'; };
        iconButtons.appendChild(discordIconBtn);

        const closeIconBtn = document.createElement('a');
        closeIconBtn.href = '#';
        closeIconBtn.style.cssText = 'display:flex;align-items:center;justify-content:center;width:40px;height:40px;background:rgba(255, 255, 255, 0.03);border:1px solid rgba(255, 255, 255, 0.08);border-radius:12px;color:#8b949e;font-size:18px;text-decoration:none;transition:all 0.3s ease;cursor:pointer;';
        closeIconBtn.innerHTML = '<i class="fa-solid fa-xmark"></i>';
        closeIconBtn.title = t('settings.close', 'Close');
        closeIconBtn.onmouseover = function() { this.style.color = '#00d4ff'; this.style.borderColor = 'rgba(0, 212, 255, 0.4)'; this.style.background = 'rgba(0, 212, 255, 0.05)'; this.style.transform = 'translateY(-2px)'; this.style.boxShadow = '0 8px 16px rgba(0, 212, 255, 0.15)'; };
        closeIconBtn.onmouseout = function() { this.style.color = '#8b949e'; this.style.borderColor = 'rgba(255, 255, 255, 0.08)'; this.style.background = 'rgba(255, 255, 255, 0.03)'; this.style.transform = 'translateY(0)'; this.style.boxShadow = 'none'; };
        iconButtons.appendChild(closeIconBtn);

        const contentWrap = document.createElement('div');
        contentWrap.className = 'newkey-scroll';
        contentWrap.style.cssText = 'flex:1 1 auto;overflow-y:auto;overflow-x:hidden;padding:24px;margin:0 24px;border:1px solid rgba(255, 255, 255, 0.05);border-radius:16px;background:rgba(5, 8, 15, 0.4);box-shadow:inset 0 4px 20px rgba(0,0,0,0.5);';

        const btnRow = document.createElement('div');
        btnRow.style.cssText = 'padding:24px 32px;display:flex;gap:12px;justify-content:space-between;align-items:center;';

        const backBtn = createSettingsButton('back', '<i class="fa-solid fa-arrow-left"></i>');
        const rightButtons = document.createElement('div');
        rightButtons.style.cssText = 'display:flex;gap:12px;';
        const refreshBtn = createSettingsButton('refresh', '<i class="fa-solid fa-arrow-rotate-right"></i>');
        const saveBtn = createSettingsButton('save', '<i class="fa-solid fa-floppy-disk" style="margin-right: 8px;"></i> Save', true);

        modal.appendChild(header);
        modal.appendChild(contentWrap);
        modal.appendChild(btnRow);
        overlay.appendChild(modal);
        document.body.appendChild(overlay);

        const state = {
            config: null,
            draft: {},
        };

        function createSettingsButton(id, text, isPrimary) {
            const btn = document.createElement('a');
            btn.id = 'nk-settings-' + id;
            btn.href = '#';
            btn.innerHTML = '<span>' + text + '</span>';

            btn.className = 'newkey-btn';
            if (isPrimary) {
                btn.classList.add('primary');
            }

            btn.onmouseover = function() {
                if (this.dataset.disabled === '1') {
                    this.style.opacity = '0.6';
                    this.style.cursor = 'not-allowed';
                    return;
                }
            };

            btn.onmouseout = function() {
                if (this.dataset.disabled === '1') {
                    this.style.opacity = '0.5';
                    return;
                }
            };

            if (isPrimary) {
                btn.dataset.disabled = '1';
                btn.style.opacity = '0.5';
                btn.style.cursor = 'not-allowed';
            }

            return btn;
        }

        header.appendChild(title);
        header.appendChild(iconButtons);
        function applyStaticTranslations() {
            title.textContent = t('settings.title', 'NewKey · Settings');
            refreshBtn.title = t('settings.refresh', 'Refresh');
            saveBtn.querySelector('span').innerHTML = '<i class="fa-solid fa-floppy-disk" style="margin-right: 8px;"></i> ' + t('settings.save', 'Save Settings');
            backBtn.title = t('Back', 'Back');
            discordIconBtn.title = t('menu.discord', 'Discord');
            closeIconBtn.title = t('settings.close', 'Close');
        }
        applyStaticTranslations();

        function setStatus(text, color) {
            let statusLine = contentWrap.querySelector('.newkey-settings-status');
            if (!statusLine) {
                statusLine = document.createElement('div');
                statusLine.className = 'newkey-settings-status';
                statusLine.style.cssText = 'font-size:13px;margin-top:10px;transform:translateY(15px);color:#8b949e;min-height:18px;text-align:center;font-weight:500;';  
                contentWrap.insertBefore(statusLine, contentWrap.firstChild);
            }
            statusLine.textContent = text || '';
            statusLine.style.color = color || '#8b949e';
        }

        function ensureDraftGroup(groupKey) {
            if (!state.draft[groupKey] || typeof state.draft[groupKey] !== 'object') {
                state.draft[groupKey] = {};
            }
            return state.draft[groupKey];
        }

        function collectChanges() {
            if (!state.config || !Array.isArray(state.config.schema)) {
                return {};
            }
            const changes = {};
            for (let i = 0; i < state.config.schema.length; i++) {
                const group = state.config.schema[i];
                if (!group || !group.key) continue;
                const options = Array.isArray(group.options) ? group.options : [];
                const draftGroup = state.draft[group.key] || {};
                const originalGroup = (state.config.values && state.config.values[group.key]) || {};
                const groupChanges = {};
                for (let j = 0; j < options.length; j++) {
                    const option = options[j];
                    if (!option || !option.key) continue;
                    const newValue = draftGroup.hasOwnProperty(option.key) ? draftGroup[option.key] : option.default;
                    const oldValue = originalGroup.hasOwnProperty(option.key) ? originalGroup[option.key] : option.default;
                    if (newValue !== oldValue) {
                        groupChanges[option.key] = newValue;
                    }
                }
                if (Object.keys(groupChanges).length > 0) {
                    changes[group.key] = groupChanges;
                }
            }
            return changes;
        }

        function updateSaveState() {
            const hasChanges = Object.keys(collectChanges()).length > 0;
            const isBusy = saveBtn.dataset.busy === '1';
            if (hasChanges && !isBusy) {
                saveBtn.dataset.disabled = '0';
                saveBtn.style.opacity = '';
                saveBtn.style.cursor = 'pointer';
            } else {
                saveBtn.dataset.disabled = '1';
                saveBtn.style.opacity = '0.5';
                saveBtn.style.cursor = 'not-allowed';
            }
        }

        function optionLabelKey(groupKey, optionKey) {
            if (groupKey === 'general') {
                if (optionKey === 'language') return 'settings.language.label';
                if (optionKey === 'donateKeys') return 'settings.donateKeys.label';
            }
            return null;
        }

        function optionDescriptionKey(groupKey, optionKey) {
            if (groupKey === 'general') {
                if (optionKey === 'language') return 'settings.language.description';
                if (optionKey === 'donateKeys') return 'settings.donateKeys.description';
            }
            return null;
        }

        function renderSettings() {
            contentWrap.innerHTML = '';
            if (!state.config || !Array.isArray(state.config.schema) || state.config.schema.length === 0) {
                const emptyState = document.createElement('div');
                emptyState.style.cssText = 'padding:16px;background:rgba(22, 27, 34, 0.6);border:1px solid rgba(255, 255, 255, 0.05);border-radius:12px;color:#e6edf3;text-align:center;';
                emptyState.textContent = t('settings.empty', 'No settings available yet.');
                contentWrap.appendChild(emptyState);
                updateSaveState();
                return;
            }

            for (let i = 0; i < state.config.schema.length; i++) {
                const group = state.config.schema[i];
                if (!group || !group.key) continue;

                const groupEl = document.createElement('div');
                groupEl.style.cssText = 'margin-bottom:24px;background:rgba(22, 27, 34, 0.4); border: 1px solid rgba(255,255,255,0.05); border-radius:16px; padding:20px;';

                const groupTitle = document.createElement('div');
                groupTitle.textContent = t('settings.' + group.key, group.label || group.key);
                if (group.key === 'general') {
                    groupTitle.style.cssText = 'font-size:22px;color:#fff;margin-bottom:20px;margin-top:-30px;font-weight:700;text-align:center; letter-spacing:0.5px;'; 
                } else {
                    groupTitle.style.cssText = 'font-size:16px;font-weight:700;color:#00d4ff;text-align:left;margin-bottom:12px;';
                }
                groupEl.appendChild(groupTitle);

                if (group.description && group.key !== 'general') {
                    const groupDesc = document.createElement('div');
                    groupDesc.style.cssText = 'margin-top:4px;font-size:13px;color:#8b949e;margin-bottom:16px;';
                    groupDesc.textContent = t('settings.' + group.key + 'Description', group.description);
                    groupEl.appendChild(groupDesc);
                }

                const options = Array.isArray(group.options) ? group.options : [];
                for (let j = 0; j < options.length; j++) {
                    const option = options[j];
                    if (!option || !option.key) continue;

                    ensureDraftGroup(group.key);
                    if (!state.draft[group.key].hasOwnProperty(option.key)) {
                        const sourceGroup = (state.config.values && state.config.values[group.key]) || {};
                        const initialValue = sourceGroup.hasOwnProperty(option.key) ? sourceGroup[option.key] : option.default;
                        state.draft[group.key][option.key] = initialValue;
                    }

                    const optionEl = document.createElement('div');
                    if (j === 0) {
                        optionEl.style.cssText = 'margin-top:0px;padding-top:0;';
                    } else {
                        optionEl.style.cssText = 'margin-top:16px;padding-top:16px;border-top:1px solid rgba(255, 255, 255, 0.05);';
                    }

                    const optionLabel = document.createElement('div');
                    optionLabel.style.cssText = 'font-size:14px;font-weight:600;color:#e6edf3;';
                    const labelKey = optionLabelKey(group.key, option.key);
                    optionLabel.textContent = t(labelKey || ('settings.' + group.key + '.' + option.key + '.label'), option.label || option.key);
                    optionEl.appendChild(optionLabel);

                    if (option.description) {
                        const optionDesc = document.createElement('div');
                        optionDesc.style.cssText = 'margin-top:4px;font-size:12px;color:#8b949e;';
                        const descKey = optionDescriptionKey(group.key, option.key);
                        optionDesc.textContent = t(descKey || ('settings.' + group.key + '.' + option.key + '.description'), option.description);
                        optionEl.appendChild(optionDesc);
                    }

                    const controlWrap = document.createElement('div');
                    controlWrap.style.cssText = 'margin-top:10px;';

                    if (option.type === 'select') {
                        const selectEl = document.createElement('select');
                        selectEl.style.cssText = 'width:100%;padding:10px 12px;background:rgba(5, 8, 15, 0.6);color:#e6edf3;border:1px solid rgba(255, 255, 255, 0.1);border-radius:8px;outline:none;transition:border-color 0.2s;';
                        selectEl.onfocus = () => selectEl.style.borderColor = '#00d4ff';
                        selectEl.onblur = () => selectEl.style.borderColor = 'rgba(255, 255, 255, 0.1)';

                        const choices = Array.isArray(option.choices) ? option.choices : [];
                        for (let c = 0; c < choices.length; c++) {
                            const choice = choices[c];
                            if (!choice) continue;
                            const choiceOption = document.createElement('option');
                            choiceOption.value = String(choice.value);
                            choiceOption.textContent = choice.label || choice.value;
                            selectEl.appendChild(choiceOption);
                        }

                        const currentValue = state.draft[group.key][option.key];
                        if (typeof currentValue !== 'undefined') {
                            selectEl.value = String(currentValue);
                        }

                        selectEl.addEventListener('change', function(){
                            state.draft[group.key][option.key] = selectEl.value;
                            try { backendLog('NewKey: language select changed to ' + selectEl.value); } catch(_) {}
                            updateSaveState();
                            setStatus(t('settings.unsaved', 'Unsaved changes'), '#00d4ff');
                        });

                        controlWrap.appendChild(selectEl);
                    } else if (option.type === 'toggle') {
                        const toggleWrap = document.createElement('div');
                        toggleWrap.style.cssText = 'display:flex;gap:12px;flex-wrap:wrap;';

                        let yesLabel = option.metadata && option.metadata.yesLabel ? String(option.metadata.yesLabel) : 'Yes';
                        let noLabel = option.metadata && option.metadata.noLabel ? String(option.metadata.noLabel) : 'No';
                        if (group.key === 'general' && option.key === 'donateKeys') {
                            yesLabel = t('settings.donateKeys.yes', yesLabel);
                            noLabel = t('settings.donateKeys.no', noLabel);
                        }

                        const yesBtn = document.createElement('a');
                        yesBtn.className = 'newkey-btn';
                        yesBtn.style.padding = '8px 16px';
                        yesBtn.href = '#';
                        yesBtn.innerHTML = '<span>' + yesLabel + '</span>';

                        const noBtn = document.createElement('a');
                        noBtn.className = 'newkey-btn';
                        noBtn.style.padding = '8px 16px';
                        noBtn.href = '#';
                        noBtn.innerHTML = '<span>' + noLabel + '</span>';

                        const yesSpan = yesBtn.querySelector('span');
                        const noSpan = noBtn.querySelector('span');

                        function refreshToggleButtons() {
                            const currentValue = state.draft[group.key][option.key] === true;
                            if (currentValue) {
                                yesBtn.style.background = 'linear-gradient(135deg, #00d4ff 0%, #007bf5 100%)';
                                yesBtn.style.color = '#fff';
                                yesBtn.style.borderColor = 'transparent';
                                if (yesSpan) yesSpan.style.color = '#fff';
                                noBtn.style.background = 'rgba(255, 255, 255, 0.05)';
                                noBtn.style.color = '#8b949e';
                                noBtn.style.borderColor = 'rgba(255, 255, 255, 0.1)';
                                if (noSpan) noSpan.style.color = '#8b949e';
                            } else {
                                noBtn.style.background = 'linear-gradient(135deg, #00d4ff 0%, #007bf5 100%)';
                                noBtn.style.color = '#fff';
                                noBtn.style.borderColor = 'transparent';
                                if (noSpan) noSpan.style.color = '#fff';
                                yesBtn.style.background = 'rgba(255, 255, 255, 0.05)';
                                yesBtn.style.color = '#8b949e';
                                yesBtn.style.borderColor = 'rgba(255, 255, 255, 0.1)';
                                if (yesSpan) yesSpan.style.color = '#8b949e';
                            }
                        }

                        yesBtn.addEventListener('click', function(e){
                            e.preventDefault();
                            state.draft[group.key][option.key] = true;
                            refreshToggleButtons();
                            updateSaveState();
                            setStatus(t('settings.unsaved', 'Unsaved changes'), '#00d4ff');
                        });

                        noBtn.addEventListener('click', function(e){
                            e.preventDefault();
                            state.draft[group.key][option.key] = false;
                            refreshToggleButtons();
                            updateSaveState();
                            setStatus(t('settings.unsaved', 'Unsaved changes'), '#00d4ff');
                        });

                        toggleWrap.appendChild(yesBtn);
                        toggleWrap.appendChild(noBtn);
                        controlWrap.appendChild(toggleWrap);
                        refreshToggleButtons();
                    } else {
                        const unsupported = document.createElement('div');
                        unsupported.style.cssText = 'font-size:12px;color:#f59e0b;';
                        unsupported.textContent = nk('common.error.unsupportedOption').replace('{type}', option.type);
                        controlWrap.appendChild(unsupported);
                    }

                    optionEl.appendChild(controlWrap);
                    groupEl.appendChild(optionEl);
                }

                contentWrap.appendChild(groupEl);
            }

            renderInstalledFixesSection();
            renderInstalledLuaSection();

            updateSaveState();
        }

        function renderInstalledFixesSection() {
            const sectionEl = document.createElement('div');
            sectionEl.id = 'newkey-installed-fixes-section';
            sectionEl.style.cssText = 'margin-top:36px;padding:24px;background:linear-gradient(135deg, rgba(0, 212, 255, 0.05) 0%, rgba(0, 123, 245, 0.08) 100%);border:1px solid rgba(0, 212, 255, 0.2);border-radius:16px;box-shadow:0 8px 24px rgba(0,0,0,0.3);position:relative;overflow:hidden;';

            const sectionGlow = document.createElement('div');
            sectionGlow.style.cssText = 'position:absolute;top:-50%;left:-50%;width:200%;height:200%;background:radial-gradient(circle, rgba(0, 212, 255, 0.08) 0%, transparent 60%);pointer-events:none;';
            sectionEl.appendChild(sectionGlow);

            const sectionTitle = document.createElement('div');
            sectionTitle.style.cssText = 'font-size:20px;color:#00d4ff;margin-bottom:24px;font-weight:800;text-align:center;text-shadow:0 2px 10px rgba(0, 212, 255, 0.4);background:linear-gradient(135deg, #00d4ff 0%, #007bf5 100%);-webkit-background-clip:text;-webkit-text-fill-color:transparent;background-clip:text;position:relative;z-index:1;letter-spacing:0.5px;';
            sectionTitle.innerHTML = '<i class="fa-solid fa-wrench" style="margin-right:10px;"></i>' + t('settings.installedFixes.title', 'Installed Fixes');
            sectionEl.appendChild(sectionTitle);

            const listContainer = document.createElement('div');
            listContainer.id = 'newkey-fixes-list';
            listContainer.style.cssText = 'min-height:50px; position:relative; z-index:1;';
            sectionEl.appendChild(listContainer);

            contentWrap.appendChild(sectionEl);

            loadInstalledFixes(listContainer);
        }

        function loadInstalledFixes(container) {
            container.innerHTML = '<div style="padding:16px;text-align:center;color:#8b949e;">' + t('settings.installedFixes.loading', 'Scanning for installed fixes...') + '</div>';

            Millennium.callServerMethod('newkey', 'GetInstalledFixes', { contentScriptQuery: '' })
                .then(function(res) {
                    const response = typeof res === 'string' ? JSON.parse(res) : res;
                    if (!response || !response.success) {
                        container.innerHTML = '<div style="padding:16px;background:rgba(244, 63, 94, 0.1);border:1px solid rgba(244, 63, 94, 0.3);border-radius:12px;color:#f43f5e;text-align:center;">' + t('settings.installedFixes.error', 'Failed to load installed fixes.') + '</div>';
                        return;
                    }

                    const fixes = Array.isArray(response.fixes) ? response.fixes : [];
                    if (fixes.length === 0) {
                        container.innerHTML = '<div style="padding:16px;background:rgba(22, 27, 34, 0.6);border:1px solid rgba(255, 255, 255, 0.05);border-radius:12px;color:#8b949e;text-align:center;">' + t('settings.installedFixes.empty', 'No fixes installed yet.') + '</div>';
                        return;
                    }

                    container.innerHTML = '';
                    for (let i = 0; i < fixes.length; i++) {
                        const fix = fixes[i];
                        const fixEl = createFixListItem(fix, container);
                        container.appendChild(fixEl);
                    }
                })
                .catch(function(err) {
                    container.innerHTML = '<div style="padding:16px;background:rgba(244, 63, 94, 0.1);border:1px solid rgba(244, 63, 94, 0.3);border-radius:12px;color:#f43f5e;text-align:center;">' + t('settings.installedFixes.error', 'Failed to load installed fixes.') + '</div>';
                });
        }

        function createFixListItem(fix, container) {
            const itemEl = document.createElement('div');
            itemEl.style.cssText = 'margin-bottom:12px;padding:16px;background:rgba(22, 27, 34, 0.8);border:1px solid rgba(255, 255, 255, 0.05);border-radius:12px;display:flex;justify-content:space-between;align-items:center;transition:all 0.3s cubic-bezier(0.25, 1, 0.5, 1);';
            itemEl.onmouseover = function() { this.style.borderColor = 'rgba(0, 212, 255, 0.4)'; this.style.background = 'rgba(30, 38, 48, 0.9)'; this.style.transform='translateY(-2px)'; this.style.boxShadow='0 8px 24px rgba(0,0,0,0.4)'; };
            itemEl.onmouseout = function() { this.style.borderColor = 'rgba(255, 255, 255, 0.05)'; this.style.background = 'rgba(22, 27, 34, 0.8)'; this.style.transform='translateY(0)'; this.style.boxShadow='none';};

            const infoDiv = document.createElement('div');
            infoDiv.style.cssText = 'flex:1;';

            const gameName = document.createElement('div');
            gameName.style.cssText = 'font-size:16px;font-weight:700;color:#fff;margin-bottom:8px;';
            gameName.textContent = fix.gameName || 'Unknown Game (' + fix.appid + ')';
            infoDiv.appendChild(gameName);

            const detailsDiv = document.createElement('div');
            detailsDiv.style.cssText = 'font-size:13px;color:#8b949e;line-height:1.6; display:flex; gap:16px; flex-wrap:wrap;';

            if (fix.fixType) {
                const typeSpan = document.createElement('div');
                typeSpan.innerHTML = '<strong style="color:#00d4ff;">' + t('settings.installedFixes.type', 'Type:') + '</strong> ' + fix.fixType;
                detailsDiv.appendChild(typeSpan);
            }

            if (fix.date) {
                const dateSpan = document.createElement('div');
                dateSpan.innerHTML = '<strong style="color:#00d4ff;">' + t('settings.installedFixes.date', 'Installed:') + '</strong> ' + fix.date;
                detailsDiv.appendChild(dateSpan);
            }

            if (fix.filesCount > 0) {
                const filesSpan = document.createElement('div');
                filesSpan.innerHTML = '<strong style="color:#00d4ff;">' + t('settings.installedFixes.files', '{count} files').replace('{count}', fix.filesCount) + '</strong>';
                detailsDiv.appendChild(filesSpan);
            }

            infoDiv.appendChild(detailsDiv);
            itemEl.appendChild(infoDiv);

            const deleteBtn = document.createElement('a');
            deleteBtn.href = '#';
            deleteBtn.style.cssText = 'display:flex;align-items:center;justify-content:center;width:44px;height:44px;background:rgba(244, 63, 94, 0.1);border:1px solid rgba(244, 63, 94, 0.3);border-radius:12px;color:#f43f5e;font-size:18px;text-decoration:none;transition:all 0.3s cubic-bezier(0.25, 1, 0.5, 1);cursor:pointer;flex-shrink:0;';
            deleteBtn.innerHTML = '<i class="fa-solid fa-trash"></i>';
            deleteBtn.title = t('settings.installedFixes.delete', 'Delete');
            deleteBtn.onmouseover = function() {
                this.style.background = 'rgba(244, 63, 94, 0.2)';
                this.style.borderColor = 'rgba(244, 63, 94, 0.6)';
                this.style.transform = 'translateY(-2px)';
                this.style.boxShadow = '0 8px 20px rgba(244, 63, 94, 0.3)';
            };
            deleteBtn.onmouseout = function() {
                this.style.background = 'rgba(244, 63, 94, 0.1)';
                this.style.borderColor = 'rgba(244, 63, 94, 0.3)';
                this.style.transform = 'translateY(0)';
                this.style.boxShadow = 'none';
            };

            deleteBtn.addEventListener('click', function(e) {
                e.preventDefault();
                if (deleteBtn.dataset.busy === '1') return;

                showNewKeyConfirm(
                    fix.gameName || 'NewKey',
                    t('settings.installedFixes.deleteConfirm', 'Are you sure you want to remove this fix? This will delete fix files and run Steam verification.'),
                    function() {
                        deleteBtn.dataset.busy = '1';
                        deleteBtn.style.opacity = '0.6';
                        deleteBtn.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i>';

                        Millennium.callServerMethod('newkey', 'UnFixGame', {
                            appid: fix.appid,
                            installPath: fix.installPath || '',
                            fixDate: fix.date || '',
                            contentScriptQuery: ''
                        })
                        .then(function(res) {
                            const response = typeof res === 'string' ? JSON.parse(res) : res;
                            if (!response || !response.success) {
                                alert(t('settings.installedFixes.deleteError', 'Failed to remove fix.'));
                                deleteBtn.dataset.busy = '0';
                                deleteBtn.style.opacity = '1';
                                deleteBtn.innerHTML = '<span><i class="fa-solid fa-trash"></i> ' + t('settings.installedFixes.delete', 'Delete') + '</span>';
                                return;
                            }
                            pollUnfixStatus(fix.appid, itemEl, deleteBtn, container);
                        })
                        .catch(function(err) {
                            alert(t('settings.installedFixes.deleteError', 'Failed to remove fix.') + ' ' + (err && err.message ? err.message : ''));
                            deleteBtn.dataset.busy = '0';
                            deleteBtn.style.opacity = '1';
                            deleteBtn.innerHTML = '<span><i class="fa-solid fa-trash"></i> ' + t('settings.installedFixes.delete', 'Delete') + '</span>';
                        });
                    },
                    function() {
                    }
                );
            });

            itemEl.appendChild(deleteBtn);
            return itemEl;
        }

        function pollUnfixStatus(appid, itemEl, deleteBtn, container) {
            let pollCount = 0;
            const maxPolls = 60;

            function checkStatus() {
                if (pollCount >= maxPolls) {
                    alert(t('settings.installedFixes.deleteError', 'Failed to remove fix.') + ' (Timeout)');
                    deleteBtn.dataset.busy = '0';
                    deleteBtn.style.opacity = '1';
                    deleteBtn.innerHTML = '<span><i class="fa-solid fa-trash"></i> ' + t('settings.installedFixes.delete', 'Delete') + '</span>';
                    return;
                }

                pollCount++;

                Millennium.callServerMethod('newkey', 'GetUnfixStatus', { appid: appid, contentScriptQuery: '' })
                    .then(function(res) {
                        const response = typeof res === 'string' ? JSON.parse(res) : res;
                        if (!response || !response.success) {
                            setTimeout(checkStatus, 500);
                            return;
                        }

                        const state = response.state || {};
                        const status = state.status;

                        if (status === 'done' && state.success) {
                            itemEl.style.transition = 'all 0.3s cubic-bezier(0.25, 1, 0.5, 1)';
                            itemEl.style.opacity = '0';
                            itemEl.style.transform = 'translateX(-30px)';
                            setTimeout(function() {
                                itemEl.remove();
                                if (container.children.length === 0) {
                                    container.innerHTML = '<div style="padding:16px;background:rgba(22, 27, 34, 0.6);border:1px solid rgba(255, 255, 255, 0.05);border-radius:12px;color:#8b949e;text-align:center;">' + t('settings.installedFixes.empty', 'No fixes installed yet.') + '</div>';
                                }
                            }, 300);
                            
                            setTimeout(function(){
                                try {
                                    const verifyUrl = 'steam://validate/' + appid;
                                    window.location.href = verifyUrl;
                                    backendLog('NewKey: Running verify for appid ' + appid);
                                } catch(_) {}
                            }, 1000);
                            
                            return;
                        } else if (status === 'failed' || (status === 'done' && !state.success)) {
                            alert(t('settings.installedFixes.deleteError', 'Failed to remove fix.') + ' ' + (state.error || ''));
                            deleteBtn.dataset.busy = '0';
                            deleteBtn.style.opacity = '1';
                            deleteBtn.innerHTML = '<span><i class="fa-solid fa-trash"></i> ' + t('settings.installedFixes.delete', 'Delete') + '</span>';
                            return;
                        } else {
                            setTimeout(checkStatus, 500);
                        }
                    })
                    .catch(function(err) {
                        setTimeout(checkStatus, 500);
                    });
            }

            checkStatus();
        }

        function renderInstalledLuaSection() {
            const sectionEl = document.createElement('div');
            sectionEl.id = 'newkey-installed-lua-section';
            sectionEl.style.cssText = 'margin-top:24px;padding:24px;background:linear-gradient(135deg, rgba(166, 138, 255, 0.05) 0%, rgba(102, 138, 244, 0.08) 100%);border:1px solid rgba(166, 138, 255, 0.2);border-radius:16px;box-shadow:0 8px 24px rgba(0,0,0,0.3);position:relative;overflow:hidden;';

            const sectionGlow = document.createElement('div');
            sectionGlow.style.cssText = 'position:absolute;top:-50%;left:-50%;width:200%;height:200%;background:radial-gradient(circle, rgba(166, 138, 255, 0.08) 0%, transparent 60%);pointer-events:none;';
            sectionEl.appendChild(sectionGlow);

            const sectionTitle = document.createElement('div');
            sectionTitle.style.cssText = 'font-size:20px;color:#a68aff;margin-bottom:24px;font-weight:800;text-align:center;text-shadow:0 2px 10px rgba(166, 138, 255, 0.4);background:linear-gradient(135deg, #a68aff 0%, #c7b5ff 100%);-webkit-background-clip:text;-webkit-text-fill-color:transparent;background-clip:text;position:relative;z-index:1;letter-spacing:0.5px;';
            sectionTitle.innerHTML = '<i class="fa-solid fa-code" style="margin-right:10px;"></i>' + t('settings.installedLua.title', 'Installed Lua Scripts');
            sectionEl.appendChild(sectionTitle);

            const listContainer = document.createElement('div');
            listContainer.id = 'newkey-lua-list';
            listContainer.style.cssText = 'min-height:50px; position:relative; z-index:1;';
            sectionEl.appendChild(listContainer);

            contentWrap.appendChild(sectionEl);

            loadInstalledLuaScripts(listContainer);
        }

        function loadInstalledLuaScripts(container) {
            container.innerHTML = '<div style="padding:16px;text-align:center;color:#8b949e;">' + t('settings.installedLua.loading', 'Scanning for installed Lua scripts...') + '</div>';

            Millennium.callServerMethod('newkey', 'GetInstalledLuaScripts', { contentScriptQuery: '' })
                .then(function(res) {
                    const response = typeof res === 'string' ? JSON.parse(res) : res;
                    if (!response || !response.success) {
                        container.innerHTML = '<div style="padding:16px;background:rgba(244, 63, 94, 0.1);border:1px solid rgba(244, 63, 94, 0.3);border-radius:12px;color:#f43f5e;text-align:center;">' + t('settings.installedLua.error', 'Failed to load installed Lua scripts.') + '</div>';
                        return;
                    }

                    const scripts = Array.isArray(response.scripts) ? response.scripts : [];
                    if (scripts.length === 0) {
                        container.innerHTML = '<div style="padding:16px;background:rgba(22, 27, 34, 0.6);border:1px solid rgba(255, 255, 255, 0.05);border-radius:12px;color:#8b949e;text-align:center;">' + t('settings.installedLua.empty', 'No Lua scripts installed yet.') + '</div>';
                        return;
                    }

                    container.innerHTML = '';

                    const hasUnknownGames = scripts.some(function(s) {
                        return s.gameName && s.gameName.startsWith('Unknown Game');
                    });

                    if (hasUnknownGames) {
                        const infoBanner = document.createElement('div');
                        infoBanner.style.cssText = 'margin-bottom:20px;padding:16px;background:rgba(245, 158, 11, 0.1);border:1px solid rgba(245, 158, 11, 0.3);border-radius:12px;color:#f59e0b;font-size:14px;display:flex;align-items:center;gap:12px; box-shadow: 0 4px 12px rgba(0,0,0,0.2);';
                        infoBanner.innerHTML = '<i class="fa-solid fa-circle-info" style="font-size:18px;"></i><span>' + t('settings.installedLua.unknownInfo', 'Games showing \'Unknown Game\' were installed manually (not via NewKey).') + '</span>';
                        container.appendChild(infoBanner);
                    }

                    for (let i = 0; i < scripts.length; i++) {
                        const script = scripts[i];
                        const scriptEl = createLuaListItem(script, container);
                        container.appendChild(scriptEl);
                    }
                })
                .catch(function(err) {
                    container.innerHTML = '<div style="padding:16px;background:rgba(244, 63, 94, 0.1);border:1px solid rgba(244, 63, 94, 0.3);border-radius:12px;color:#f43f5e;text-align:center;">' + t('settings.installedLua.error', 'Failed to load installed Lua scripts.') + '</div>';
                });
        }

        function createLuaListItem(script, container) {
            const itemEl = document.createElement('div');
            itemEl.style.cssText = 'margin-bottom:12px;padding:16px;background:rgba(22, 27, 34, 0.8);border:1px solid rgba(255, 255, 255, 0.05);border-radius:12px;display:flex;justify-content:space-between;align-items:center;transition:all 0.3s cubic-bezier(0.25, 1, 0.5, 1);';
            itemEl.onmouseover = function() { this.style.borderColor = 'rgba(166, 138, 255, 0.4)'; this.style.background = 'rgba(30, 38, 48, 0.9)'; this.style.transform='translateY(-2px)'; this.style.boxShadow='0 8px 24px rgba(0,0,0,0.4)'; };
            itemEl.onmouseout = function() { this.style.borderColor = 'rgba(255, 255, 255, 0.05)'; this.style.background = 'rgba(22, 27, 34, 0.8)'; this.style.transform='translateY(0)'; this.style.boxShadow='none';};

            const infoDiv = document.createElement('div');
            infoDiv.style.cssText = 'flex:1;';

            const gameName = document.createElement('div');
            gameName.style.cssText = 'font-size:16px;font-weight:700;color:#fff;margin-bottom:8px;';
            gameName.textContent = script.gameName || 'Unknown Game (' + script.appid + ')';

            if (script.isDisabled) {
                const disabledBadge = document.createElement('span');
                disabledBadge.style.cssText = 'margin-left:12px;padding:4px 10px;background:rgba(244, 63, 94, 0.15);border:1px solid rgba(244, 63, 94, 0.3);border-radius:6px;font-size:11px;color:#f43f5e;font-weight:600;';
                disabledBadge.textContent = t('settings.installedLua.disabled', 'Disabled');
                gameName.appendChild(disabledBadge);
            }

            infoDiv.appendChild(gameName);

            const detailsDiv = document.createElement('div');
            detailsDiv.style.cssText = 'font-size:13px;color:#8b949e;line-height:1.6;';

            if (script.modifiedDate) {
                const dateSpan = document.createElement('div');
                dateSpan.innerHTML = '<strong style="color:#a68aff;">' + t('settings.installedLua.modified', 'Modified:') + '</strong> ' + script.modifiedDate;
                detailsDiv.appendChild(dateSpan);
            }

            infoDiv.appendChild(detailsDiv);
            itemEl.appendChild(infoDiv);

            const deleteBtn = document.createElement('a');
            deleteBtn.href = '#';
            deleteBtn.style.cssText = 'display:flex;align-items:center;justify-content:center;width:44px;height:44px;background:rgba(244, 63, 94, 0.1);border:1px solid rgba(244, 63, 94, 0.3);border-radius:12px;color:#f43f5e;font-size:18px;text-decoration:none;transition:all 0.3s cubic-bezier(0.25, 1, 0.5, 1);cursor:pointer;flex-shrink:0;';
            deleteBtn.innerHTML = '<i class="fa-solid fa-trash"></i>';
            deleteBtn.title = t('settings.installedLua.delete', 'Remove');
            deleteBtn.onmouseover = function() {
                this.style.background = 'rgba(244, 63, 94, 0.2)';
                this.style.borderColor = 'rgba(244, 63, 94, 0.6)';
                this.style.transform = 'translateY(-2px)';
                this.style.boxShadow = '0 8px 20px rgba(244, 63, 94, 0.3)';
            };
            deleteBtn.onmouseout = function() {
                this.style.background = 'rgba(244, 63, 94, 0.1)';
                this.style.borderColor = 'rgba(244, 63, 94, 0.3)';
                this.style.transform = 'translateY(0)';
                this.style.boxShadow = 'none';
            };

            deleteBtn.addEventListener('click', function(e) {
                e.preventDefault();
                if (deleteBtn.dataset.busy === '1') return;

                showNewKeyConfirm(
                    script.gameName || 'NewKey',
                    t('settings.installedLua.deleteConfirm', 'Remove via NewKey for this game?'),
                    function() {
                        deleteBtn.dataset.busy = '1';
                        deleteBtn.style.opacity = '0.6';
                        deleteBtn.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i>';

                        Millennium.callServerMethod('newkey', 'DeleteNewKeyForApp', {
                            appid: script.appid,
                            contentScriptQuery: ''
                        })
                        .then(function(res) {
                            const response = typeof res === 'string' ? JSON.parse(res) : res;
                            if (!response || !response.success) {
                                alert(t('settings.installedLua.deleteError', 'Failed to remove Lua script.'));
                                deleteBtn.dataset.busy = '0';
                                deleteBtn.style.opacity = '1';
                                deleteBtn.innerHTML = '<span><i class="fa-solid fa-trash"></i> ' + t('settings.installedLua.delete', 'Delete') + '</span>';
                                return;
                            }

                            itemEl.style.transition = 'all 0.3s cubic-bezier(0.25, 1, 0.5, 1)';
                            itemEl.style.opacity = '0';
                            itemEl.style.transform = 'translateX(-30px)';
                            setTimeout(function() {
                                itemEl.remove();
                                if (container.children.length === 0) {
                                    container.innerHTML = '<div style="padding:16px;background:rgba(22, 27, 34, 0.6);border:1px solid rgba(255, 255, 255, 0.05);border-radius:12px;color:#8b949e;text-align:center;">' + t('settings.installedLua.empty', 'No Lua scripts installed yet.') + '</div>';
                                }
                            }, 300);
                        })
                        .catch(function(err) {
                            alert(t('settings.installedLua.deleteError', 'Failed to remove Lua script.') + ' ' + (err && err.message ? err.message : ''));
                            deleteBtn.dataset.busy = '0';
                            deleteBtn.style.opacity = '1';
                            deleteBtn.innerHTML = '<span><i class="fa-solid fa-trash"></i> ' + t('settings.installedLua.delete', 'Delete') + '</span>';
                        });
                    },
                    function() {
                    }
                );
            });

            itemEl.appendChild(deleteBtn);
            return itemEl;
        }

        function handleLoad(force) {
            setStatus(t('settings.loading', 'Loading settings...'), '#00d4ff');
            saveBtn.dataset.disabled = '1';
            saveBtn.style.opacity = '0.5';
            contentWrap.innerHTML = '<div style="padding:24px;color:#8b949e;text-align:center;">' + t('common.status.loading', 'Loading...') + '</div>';

            return fetchSettingsConfig(force).then(function(config){
                state.config = {
                    schemaVersion: config.schemaVersion,
                    schema: Array.isArray(config.schema) ? config.schema : [],
                    values: initialiseSettingsDraft(config),
                    language: config.language,
                    locales: config.locales,
                };
                state.draft = initialiseSettingsDraft(config);
                applyStaticTranslations();
                renderSettings();
                setStatus('', '#8b949e');
            }).catch(function(err){
                const message = err && err.message ? err.message : t('settings.error', 'Failed to load settings.');
                contentWrap.innerHTML = '<div style="padding:24px;color:#f43f5e;text-align:center;background:rgba(244, 63, 94, 0.1);border-radius:12px;border:1px solid rgba(244, 63, 94, 0.3);">' + message + '</div>';
                setStatus(t('common.status.error', 'Error') + ': ' + message, '#f43f5e');
            });
        }

        backBtn.addEventListener('click', function(e) {
            e.preventDefault();
            if (typeof onBack === 'function') {
                overlay.remove();
                onBack();
            }
        });

        rightButtons.appendChild(refreshBtn);
        rightButtons.appendChild(saveBtn);
        btnRow.appendChild(backBtn);
        btnRow.appendChild(rightButtons);

        refreshBtn.addEventListener('click', function(e){
            e.preventDefault();
            if (refreshBtn.dataset.busy === '1') return;
            refreshBtn.dataset.busy = '1';
            handleLoad(true).finally(function(){
                refreshBtn.dataset.busy = '0';
                refreshBtn.style.opacity = '1';
                applyStaticTranslations();
            });
        });

        saveBtn.addEventListener('click', function(e){
            e.preventDefault();
            if (saveBtn.dataset.disabled === '1' || saveBtn.dataset.busy === '1') return;

            const changes = collectChanges();
            try { backendLog('NewKey: collectChanges payload ' + JSON.stringify(changes)); } catch(_) {}
            if (!changes || Object.keys(changes).length === 0) {
                setStatus(t('settings.noChanges', 'No changes to save.'), '#8b949e');
                updateSaveState();
                return;
            }

            saveBtn.dataset.busy = '1';
            saveBtn.style.opacity = '0.5';
            setStatus(t('settings.saving', 'Saving...'), '#00d4ff');

            const payloadToSend = JSON.parse(JSON.stringify(changes));
            try { backendLog('NewKey: sending settings payload ' + JSON.stringify(payloadToSend)); } catch(_) {}
            Millennium.callServerMethod('newkey', 'ApplySettingsChanges', {
                contentScriptQuery: '',
                changesJson: JSON.stringify(payloadToSend)
            }).then(function(res){
                const response = typeof res === 'string' ? JSON.parse(res) : res;
                if (!response || response.success !== true) {
                    if (response && response.errors) {
                        const errorParts = [];
                        for (const groupKey in response.errors) {
                            if (!Object.prototype.hasOwnProperty.call(response.errors, groupKey)) continue;
                            const optionErrors = response.errors[groupKey];
                            for (const optionKey in optionErrors) {
                                if (!Object.prototype.hasOwnProperty.call(optionErrors, optionKey)) continue;
                                const errorMsg = optionErrors[optionKey];
                                errorParts.push(groupKey + '.' + optionKey + ': ' + errorMsg);
                            }
                        }
                        const errText = errorParts.length ? errorParts.join('\n') : 'Validation failed.';
                        setStatus(errText, '#f43f5e');
                    } else {
                        const message = (response && response.error) ? response.error : t('settings.saveError', 'Failed to save settings.');
                        setStatus(message, '#f43f5e');
                    }
                    return;
                }

                const newValues = (response && response.values && typeof response.values === 'object') ? response.values : state.draft;
                state.config.values = initialiseSettingsDraft({ schema: state.config.schema, values: newValues });
                state.draft = initialiseSettingsDraft({ schema: state.config.schema, values: newValues });

                try {
                    if (window.__NewKeySettings) {
                        window.__NewKeySettings.values = JSON.parse(JSON.stringify(state.config.values));
                        window.__NewKeySettings.schemaVersion = state.config.schemaVersion;
                        window.__NewKeySettings.lastFetched = Date.now();
                        if (response && response.translations && typeof response.translations === 'object') {
                            window.__NewKeySettings.translations = response.translations;
                        }
                        if (response && response.language) {
                            window.__NewKeySettings.language = response.language;
                        }
                    }
                } catch(_) {}

                if (response && response.translations && typeof response.translations === 'object') {
                    applyTranslationBundle({
                        language: response.language || (window.__NewKeyI18n && window.__NewKeyI18n.language) || 'en',
                        locales: (window.__NewKeyI18n && window.__NewKeyI18n.locales) || (state.config && state.config.locales) || [],
                        strings: response.translations
                    });
                    applyStaticTranslations();
                    updateButtonTranslations();
                }

                renderSettings();
                setStatus(t('settings.saveSuccess', 'Settings saved successfully.'), '#10b981');
            }).catch(function(err){
                const message = err && err.message ? err.message : t('settings.saveError', 'Failed to save settings.');
                setStatus(message, '#f43f5e');
            }).finally(function(){
                saveBtn.dataset.busy = '0';
                applyStaticTranslations();
                updateSaveState();
            });
        });

        closeIconBtn.addEventListener('click', function(e){
            e.preventDefault();
            overlay.remove();
        });

        discordIconBtn.addEventListener('click', function(e) {
            e.preventDefault();
            const url = 'https://discord.gg/nsCGfP22';
            try {
                Millennium.callServerMethod('newkey', 'OpenExternalUrl', { url, contentScriptQuery: '' });
            } catch(_) {}
        });

        overlay.addEventListener('click', function(e){
            if (e.target === overlay) {
            overlay.remove();
        }
        });

        handleLoad(!!forceRefresh);
    }

    function closeSettingsOverlay() {
        try {
            var list = document.getElementsByClassName('newkey-settings-overlay');
            while (list && list.length > 0) {
                try { list[0].remove(); } catch(_) { break; }
            }
            var list2 = document.getElementsByClassName('newkey-overlay');
            while (list2 && list2.length > 0) {
                try { list2[0].remove(); } catch(_) { break; }
            }
        } catch(_) {}
    }

    function ShowNewKeyAlert(title, message, onClose) {
        if (document.querySelector('.newkey-alert-overlay')) return;

        ensureNewKeyStyles();
        const overlay = document.createElement('div');
        overlay.className = 'newkey-alert-overlay';
        overlay.style.cssText = 'position:fixed;inset:0;background:rgba(5, 8, 15, 0.85);backdrop-filter:blur(16px);z-index:100001;display:flex;align-items:center;justify-content:center;animation:fadeIn 0.2s ease-out;';

        const modal = document.createElement('div');
        modal.style.cssText = 'background:linear-gradient(145deg, #0d1117 0%, #161b22 100%);color:#fff;border:1px solid rgba(255, 255, 255, 0.08);border-radius:16px;min-width:400px;max-width:520px;padding:32px 36px;box-shadow:0 24px 48px rgba(0,0,0,0.9), 0 0 0 1px rgba(0, 212, 255, 0.1);animation:slideUp 0.3s cubic-bezier(0.25, 1, 0.5, 1);';

        const titleEl = document.createElement('div');
        titleEl.style.cssText = 'font-size:24px;font-weight:800;letter-spacing:0.5px;margin-bottom:20px;text-align:left;background:linear-gradient(135deg, #00d4ff 0%, #007bf5 100%);-webkit-background-clip:text;-webkit-text-fill-color:transparent;text-shadow:0 4px 12px rgba(0, 212, 255, 0.3);';
        titleEl.textContent = String(title || 'NewKey');

        const messageEl = document.createElement('div');
        messageEl.style.cssText = 'font-size:15px;line-height:1.6;margin-bottom:32px;color:#e6edf3;text-align:left;padding:0;';
        messageEl.textContent = String(message || '');

        const btnRow = document.createElement('div');
        btnRow.style.cssText = 'display:flex;justify-content:flex-end;';

        const okBtn = document.createElement('a');
        okBtn.href = '#';
        okBtn.className = 'newkey-btn primary';
        okBtn.style.minWidth = '140px';
        okBtn.innerHTML = `<span>${nk('Close')}</span>`;
        okBtn.onclick = function(e) {
            e.preventDefault();
            overlay.remove();
            try { onClose && onClose(); } catch(_) {}
        };

        btnRow.appendChild(okBtn);

        modal.appendChild(titleEl);
        modal.appendChild(messageEl);
        modal.appendChild(btnRow);
        overlay.appendChild(modal);

        overlay.addEventListener('click', function(e) {
            if (e.target === overlay) {
                overlay.remove();
                try { onClose && onClose(); } catch(_) {}
            }
        });

        document.body.appendChild(overlay);
    }

    function showNewKeyAlert(title, message) {
        try {
            ShowNewKeyAlert(title, message);
        } catch(err) {
            backendLog('NewKey: Alert error, falling back: ' + err);
            try { alert(String(title) + '\n\n' + String(message)); } catch(_) {}
        }
    }

    function showNewKeyConfirm(title, message, onConfirm, onCancel) {
        closeSettingsOverlay();

        if (document.querySelector('.newkey-confirm-overlay')) return;

        ensureNewKeyStyles();
        const overlay = document.createElement('div');
        overlay.className = 'newkey-confirm-overlay';
        overlay.style.cssText = 'position:fixed;inset:0;background:rgba(5, 8, 15, 0.85);backdrop-filter:blur(16px);z-index:100001;display:flex;align-items:center;justify-content:center;animation:fadeIn 0.2s ease-out;';

        const modal = document.createElement('div');
        modal.style.cssText = 'background:linear-gradient(145deg, #0d1117 0%, #161b22 100%);color:#fff;border:1px solid rgba(255, 255, 255, 0.08);border-radius:16px;min-width:420px;max-width:540px;padding:32px 36px;box-shadow:0 24px 48px rgba(0,0,0,0.9), 0 0 0 1px rgba(0, 212, 255, 0.1);animation:slideUp 0.3s cubic-bezier(0.25, 1, 0.5, 1);';

        const titleEl = document.createElement('div');
        titleEl.style.cssText = 'font-size:24px;font-weight:800;letter-spacing:0.5px;margin-bottom:20px;text-align:center;background:linear-gradient(135deg, #00d4ff 0%, #007bf5 100%);-webkit-background-clip:text;-webkit-text-fill-color:transparent;text-shadow:0 4px 12px rgba(0, 212, 255, 0.3);';
        titleEl.textContent = String(title || 'NewKey');

        const messageEl = document.createElement('div');
        messageEl.style.cssText = 'font-size:15px;line-height:1.6;margin-bottom:32px;color:#e6edf3;text-align:center;';
        messageEl.textContent = String(message || nk('Are you sure?'));

        const btnRow = document.createElement('div');
        btnRow.style.cssText = 'display:flex;gap:16px;justify-content:center;';

        const cancelBtn = document.createElement('a');
        cancelBtn.href = '#';
        cancelBtn.className = 'newkey-btn';
        cancelBtn.style.flex = '1';
        cancelBtn.innerHTML = `<span>${nk('Cancel')}</span>`;
        cancelBtn.onclick = function(e) {
            e.preventDefault();
            overlay.remove();
            try { onCancel && onCancel(); } catch(_) {}
        };
        const confirmBtn = document.createElement('a');
        confirmBtn.href = '#';
        confirmBtn.className = 'newkey-btn primary';
        confirmBtn.style.flex = '1';
        confirmBtn.innerHTML = `<span>${nk('Confirm')}</span>`;
        confirmBtn.onclick = function(e) {
            e.preventDefault();
            overlay.remove();
            try { onConfirm && onConfirm(); } catch(_) {}
        };

        btnRow.appendChild(cancelBtn);
        btnRow.appendChild(confirmBtn);

        modal.appendChild(titleEl);
        modal.appendChild(messageEl);
        modal.appendChild(btnRow);
        overlay.appendChild(modal);

        overlay.addEventListener('click', function(e) {
            if (e.target === overlay) {
                overlay.remove();
                try { onCancel && onCancel(); } catch(_) {}
            }
        });

        document.body.appendChild(overlay);
    }

    function ensureStyles() {
        if (!document.getElementById('newkey-spacing-styles')) {
            const style = document.createElement('style');
            style.id = 'newkey-spacing-styles';
            style.textContent = '.newkey-restart-button, .newkey-button, .newkey-icon-button{ margin-left:6px !important; }';
            document.head.appendChild(style); 
        }
    }

    function updateButtonTranslations() {
        try {
            const restartBtn = document.querySelector('.newkey-restart-button');
            if (restartBtn) {
                const restartText = nk('Restart Steam');
                restartBtn.title = restartText;
                restartBtn.setAttribute('data-tooltip-text', restartText);
                const rspan = restartBtn.querySelector('span');
                if (rspan) {
                    rspan.textContent = restartText;
                }
            }
            
            const newkeyBtn = document.querySelector('.newkey-button');
            if (newkeyBtn) {
                const addViaText = nk('Add via NewKey');
                newkeyBtn.title = addViaText;
                newkeyBtn.setAttribute('data-tooltip-text', addViaText);
                const span = newkeyBtn.querySelector('span');
                if (span) {
                    span.textContent = addViaText;
                }
            }
        } catch(err) {
            backendLog('NewKey: updateButtonTranslations error: ' + err);
        }
    }

    function addNewKeyButton() {
        const currentUrl = window.location.href;
        if (window.__NewKeyLastUrl !== currentUrl) {
            window.__NewKeyLastUrl = currentUrl;
            window.__NewKeyButtonInserted = false;
            window.__NewKeyRestartInserted = false;
            window.__NewKeyIconInserted = false;
            window.__NewKeyPresenceCheckInFlight = false;
            window.__NewKeyPresenceCheckAppId = undefined;
            ensureTranslationsLoaded(false).then(function() {
                updateButtonTranslations();
            });
        }
        
        const steamdbContainer = document.querySelector('.steamdb-buttons') || 
                                document.querySelector('[data-steamdb-buttons]') ||
                                document.querySelector('.apphub_OtherSiteInfo');

        if (steamdbContainer) {
            const existingBtn = document.querySelector('.newkey-button');
            if (existingBtn) {
                ensureTranslationsLoaded(false).then(function() {
                    updateButtonTranslations();
                });
            }
            
            if (existingBtn || window.__NewKeyButtonInserted) {
                if (!logState.existsOnce) { backendLog('NewKey button already exists, skipping'); logState.existsOnce = true; }
                return;
            }

            try {
                if (!document.querySelector('.newkey-restart-button') && !window.__NewKeyRestartInserted) {
                    ensureStyles();
                    const referenceBtn = steamdbContainer.querySelector('a');
                    const restartBtn = document.createElement('a');
                    if (referenceBtn && referenceBtn.className) {
                        restartBtn.className = referenceBtn.className + ' newkey-restart-button';
                    } else {
                        restartBtn.className = 'btnv6_blue_hoverfade btn_medium newkey-restart-button';
                    }
                    restartBtn.href = '#';
                    const restartText = nk('Restart Steam');
                    restartBtn.title = restartText;
                    restartBtn.setAttribute('data-tooltip-text', restartText);
                    const rspan = document.createElement('span');
                    rspan.textContent = restartText;
                    restartBtn.appendChild(rspan);
                    try {
                        if (referenceBtn) {
                            const cs = window.getComputedStyle(referenceBtn);
                            restartBtn.style.marginLeft = cs.marginLeft;
                            restartBtn.style.marginRight = cs.marginRight;
                        }
                    } catch(_) {}

                    restartBtn.addEventListener('click', function(e){
                        e.preventDefault();
                        try {
                            closeSettingsOverlay();
                            showNewKeyConfirm('NewKey', nk('Restart Steam now?'),
                                function() { try { Millennium.callServerMethod('newkey', 'RestartSteam', { contentScriptQuery: '' }); } catch(_) {} },
                                function() { }
                            );
                        } catch(_) {
                            showNewKeyConfirm('NewKey', nk('Restart Steam now?'),
                                function() { try { Millennium.callServerMethod('newkey', 'RestartSteam', { contentScriptQuery: '' }); } catch(_) {} },
                                function() { }
                            );
                        }
                    });

                    if (referenceBtn && referenceBtn.parentElement) {
                        referenceBtn.after(restartBtn);
                    } else {
                        steamdbContainer.appendChild(restartBtn);
                    }
                    try {
                        if (!document.querySelector('.newkey-icon-button') && !window.__NewKeyIconInserted) {
                            const iconBtn = document.createElement('a');
                            if (referenceBtn && referenceBtn.className) {
                                iconBtn.className = referenceBtn.className + ' newkey-icon-button';
                            } else {
                                iconBtn.className = 'btnv6_blue_hoverfade btn_medium newkey-icon-button';
                            }
                            iconBtn.href = '#';
                            iconBtn.title = 'NewKey Helper';
                            iconBtn.setAttribute('data-tooltip-text', 'NewKey Helper');
                            try {
                                if (referenceBtn) {
                                    const cs = window.getComputedStyle(referenceBtn);
                                    iconBtn.style.marginLeft = cs.marginLeft;
                                    iconBtn.style.marginRight = cs.marginRight;
                                }
                            } catch(_) {}
                            const ispan = document.createElement('span');
                            const img = document.createElement('img');
                            img.alt = '';
                            img.style.height = '16px';
                            img.style.width = '16px';
                            img.style.verticalAlign = 'middle';
                            try {
                                Millennium.callServerMethod('newkey', 'GetIconDataUrl', { contentScriptQuery: '' }).then(function(res){
                                    try {
                                        const payload = typeof res === 'string' ? JSON.parse(res) : res;
                                        if (payload && payload.success && payload.dataUrl) {
                                            img.src = payload.dataUrl;
                                        } else {
                                            img.src = 'NewKey/newkey-icon.png';
                                        }
                                    } catch(_) { img.src = 'NewKey/newkey-icon.png'; }
                                });
                            } catch(_) {
                                img.src = 'NewKey/newkey-icon.png';
                            }
                            img.onerror = function(){
                                ispan.innerHTML = '<svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor" xmlns="http://www.w3.org/2000/svg"><path d="M12 8a4 4 0 100 8 4 4 0 000-8zm9.94 3.06l-2.12-.35a7.962 7.962 0 00-1.02-2.46l1.29-1.72a.75.75 0 00-.09-.97l-1.41-1.41a.75.75 0 00-.97-.09l-1.72 1.29c-.77-.44-1.6-.78-2.46-1.02L13.06 2.06A.75.75 0 0012.31 2h-1.62a.75.75 0 00-.75.65l-.35 2.12a7.962 7.962 0 00-2.46 1.02L5 4.6a.75.75 0 00-.97.09L2.62 6.1a.75.75 0 00-.09.97l1.29 1.72c-.44.77-.78 1.6-1.02 2.46l-2.12.35a.75.75 0 00-.65.75v1.62c0 .37.27.69.63.75l2.14.36c.24.86.58 1.69 1.02 2.46L2.53 18a.75.75 0 00.09.97l1.41 1.41c.26.26.67.29.97.09l1.72-1.29c.77.44 1.6.78 2.46 1.02l.35 2.12c.06.36.38.63.75.63h1.62c.37 0 .69-.27.75-.63l.36-2.14c.86-.24 1.69-.58 2.46-1.02l1.72 1.29c.3.2.71.17.97-.09l1.41-1.41c.26-.26.29-.67.09-.97l-1.29-1.72c.44-.77.78-1.6 1.02-2.46l2.12-.35c.36-.06.63-.38.63-.75v-1.62a.75.75 0 00-.65-.75z"/></svg>';
                            };
                            ispan.appendChild(img);
                            iconBtn.appendChild(ispan);
                            iconBtn.addEventListener('click', function(e){ e.preventDefault(); showSettingsPopup(); });
                            restartBtn.after(iconBtn);
                            window.__NewKeyIconInserted = true;
                            backendLog('Inserted Icon button');
                        }
                    } catch(_) {}
                    window.__NewKeyRestartInserted = true;
                    backendLog('Inserted Restart Steam button');
                }
            } catch(_) {}

            if (document.querySelector('.newkey-button') || window.__NewKeyButtonInserted) {
                return;
            }
            
            let referenceBtn = steamdbContainer.querySelector('a');
            const newkeyButton = document.createElement('a');
            newkeyButton.href = '#';
            if (referenceBtn && referenceBtn.className) {
                newkeyButton.className = referenceBtn.className + ' newkey-button';
            } else {
                newkeyButton.className = 'btnv6_blue_hoverfade btn_medium newkey-button';
            }
            const span = document.createElement('span');
            const addViaText = nk('Add via NewKey');
            span.textContent = addViaText;
            newkeyButton.appendChild(span);
            newkeyButton.title = addViaText;
            newkeyButton.setAttribute('data-tooltip-text', addViaText);
            try {
                if (referenceBtn) {
                    const cs = window.getComputedStyle(referenceBtn);
                    newkeyButton.style.marginLeft = cs.marginLeft;
                    newkeyButton.style.marginRight = cs.marginRight;
                }
            } catch(_) {}
            
            newkeyButton.addEventListener('click', function(e) {
                e.preventDefault();
                backendLog('NewKey button clicked (delegated handler will process)');
            });
            
            try {
                const match = window.location.href.match(/https:\/\/store\.steampowered\.com\/app\/(\d+)/) || window.location.href.match(/https:\/\/steamcommunity\.com\/app\/(\d+)/);
                const appid = match ? parseInt(match[1], 10) : NaN;
                if (!isNaN(appid) && typeof Millennium !== 'undefined' && typeof Millennium.callServerMethod === 'function') {
                    if (window.__NewKeyPresenceCheckInFlight && window.__NewKeyPresenceCheckAppId === appid) {
                        return;
                    }
                    window.__NewKeyPresenceCheckInFlight = true;
                    window.__NewKeyPresenceCheckAppId = appid;
                    window.__NewKeyCurrentAppId = appid;
                    Millennium.callServerMethod('newkey', 'HasNewKeyForApp', { appid, contentScriptQuery: '' }).then(function(res){
                        try {
                            const payload = typeof res === 'string' ? JSON.parse(res) : res;
                            if (payload && payload.success && payload.exists === true) {
                                backendLog('NewKey already present for this app; not inserting button');
                                window.__NewKeyPresenceCheckInFlight = false;
                                return; 
                            }
                            if (!document.querySelector('.newkey-button') && !window.__NewKeyButtonInserted) {
                                const restartExisting = steamdbContainer.querySelector('.newkey-restart-button');
                                if (restartExisting && restartExisting.after) {
                                    restartExisting.after(newkeyButton);
                                } else if (referenceBtn && referenceBtn.after) {
                                    referenceBtn.after(newkeyButton);
                                } else {
                                    steamdbContainer.appendChild(newkeyButton);
                                }
                                window.__NewKeyButtonInserted = true;
                                backendLog('NewKey button inserted');
                            }
                            window.__NewKeyPresenceCheckInFlight = false;
                        } catch(_) {
                            if (!document.querySelector('.newkey-button') && !window.__NewKeyButtonInserted) {
                                steamdbContainer.appendChild(newkeyButton);
                                window.__NewKeyButtonInserted = true;
                                backendLog('NewKey button inserted');
                            }
                            window.__NewKeyPresenceCheckInFlight = false;
                        }
                    });
                } else {
                    if (!document.querySelector('.newkey-button') && !window.__NewKeyButtonInserted) {
                        const restartExisting = steamdbContainer.querySelector('.newkey-restart-button');
                        if (restartExisting && restartExisting.after) {
                            restartExisting.after(newkeyButton);
                        } else if (referenceBtn && referenceBtn.after) {
                            referenceBtn.after(newkeyButton);
                        } else {
                            steamdbContainer.appendChild(newkeyButton);
                        }
                        window.__NewKeyButtonInserted = true;
                        backendLog('NewKey button inserted');
                    }
                }
            } catch(_) {
                if (!document.querySelector('.newkey-button') && !window.__NewKeyButtonInserted) {
                    const restartExisting = steamdbContainer.querySelector('.newkey-restart-button');
                    if (restartExisting && restartExisting.after) {
                        restartExisting.after(newkeyButton);
                    } else if (referenceBtn && referenceBtn.after) {
                        referenceBtn.after(newkeyButton);
                    } else {
                        steamdbContainer.appendChild(newkeyButton);
                    }
                    window.__NewKeyButtonInserted = true;
                    backendLog('NewKey button inserted');
                }
            }
        } else {
            if (!logState.missingOnce) { backendLog('NewKey: steamdbContainer not found on this page'); logState.missingOnce = true; }
        }
    }
    
    function onFrontendReady() {
        addNewKeyButton();
        try {
            if (typeof Millennium !== 'undefined' && typeof Millennium.callServerMethod === 'function') {
                Millennium.callServerMethod('newkey', 'GetInitApisMessage', { contentScriptQuery: '' }).then(function(res){
                    try {
                        const payload = typeof res === 'string' ? JSON.parse(res) : res;
                        if (payload && payload.message) {
                            const msg = String(payload.message);
                            const isUpdateMsg = msg.toLowerCase().includes('update') || msg.toLowerCase().includes('restart');
                            
                            if (isUpdateMsg) {
                                showNewKeyConfirm('NewKey', msg, function() {
                                    try { Millennium.callServerMethod('newkey', 'RestartSteam', { contentScriptQuery: '' }); } catch(_) {}
                                }, function() {
                                });
                            } else {
                                ShowNewKeyAlert('NewKey', msg);
                            }
                        }
                    } catch(_){ }
                });
                try {
                    if (!sessionStorage.getItem('NewKeyLoadedAppsGate')) {
                        sessionStorage.setItem('NewKeyLoadedAppsGate', '1');
                        Millennium.callServerMethod('newkey', 'ReadLoadedApps', { contentScriptQuery: '' }).then(function(res){
                            try {
                                const payload = typeof res === 'string' ? JSON.parse(res) : res;
                                const apps = (payload && payload.success && Array.isArray(payload.apps)) ? payload.apps : [];
                                if (apps.length > 0) {
                                    showLoadedAppsPopup(apps);
                                }
                            } catch(_){ }
                        });
                    }
                } catch(_){ }
            }
        } catch(_) { }
    }
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', onFrontendReady);
    } else {
        onFrontendReady();
    }
    
    document.addEventListener('click', function(evt) {
        const anchor = evt.target && (evt.target.closest ? evt.target.closest('.newkey-button') : null);
        if (anchor) {
            evt.preventDefault();
            backendLog('NewKey delegated click');
            if (!document.querySelector('.newkey-overlay')) {
                showTestPopup();
            }
            try {
                const match = window.location.href.match(/https:\/\/store\.steampowered\.com\/app\/(\d+)/) || window.location.href.match(/https:\/\/steamcommunity\.com\/app\/(\d+)/);
                const appid = match ? parseInt(match[1], 10) : NaN;
                if (!isNaN(appid) && typeof Millennium !== 'undefined' && typeof Millennium.callServerMethod === 'function') {
                    if (runState.inProgress && runState.appid === appid) {
                        backendLog('NewKey: operation already in progress for this appid');
                        return;
                    }
                    runState.inProgress = true;
                    runState.appid = appid;
                    Millennium.callServerMethod('newkey', 'StartAddViaNewKey', { appid, contentScriptQuery: '' });
                    startPolling(appid);
                }
            } catch(_) {}
        }
    }, true);

    function startPolling(appid){
        let done = false;
        const timer = setInterval(() => {
            if (done) { clearInterval(timer); return; }
            try {
                Millennium.callServerMethod('newkey', 'GetAddViaNewKeyStatus', { appid, contentScriptQuery: '' }).then(function(res){
                    try {
                        const payload = typeof res === 'string' ? JSON.parse(res) : res;
                        const st = payload && payload.state ? payload.state : {};
                        
                        const overlay = document.querySelector('.newkey-overlay');
                        const title = overlay ? overlay.querySelector('.newkey-title') : null;
                        const status = overlay ? overlay.querySelector('.newkey-status') : null;
                        const wrap = overlay ? overlay.querySelector('.newkey-progress-wrap') : null;
                        const percent = overlay ? overlay.querySelector('.newkey-percent') : null;
                        const bar = overlay ? overlay.querySelector('.newkey-progress-bar') : null;
                        
                        if (st.currentApi && title) title.textContent = nk('NewKey · {api}').replace('{api}', st.currentApi);
                        if (status) {
                            if (st.status === 'checking') status.textContent = nk('Checking availability…');
                            if (st.status === 'downloading') status.textContent = nk('Downloading…');
                            if (st.status === 'processing') status.textContent = nk('Processing package…');
                            if (st.status === 'installing') status.textContent = nk('Installing…');
                            if (st.status === 'done') status.textContent = nk('Finishing…');
                            if (st.status === 'failed') status.textContent = nk('Failed');
                        }
                        if (st.status === 'downloading'){
                            if (wrap && wrap.style.display === 'none') wrap.style.display = 'block';
                            if (percent && percent.style.display === 'none') percent.style.display = 'block';
                            const total = st.totalBytes || 0; const read = st.bytesRead || 0;
                            let pct = total > 0 ? Math.floor((read/total)*100) : (read ? 1 : 0);
                            if (pct > 100) pct = 100; if (pct < 0) pct = 0;
                            if (bar) bar.style.width = pct + '%';
                            if (percent) percent.textContent = pct + '%';
                            const cancelBtn = overlay ? overlay.querySelector('.newkey-cancel-btn') : null;
                            if (cancelBtn) cancelBtn.style.display = '';
                        }
                        if (st.status === 'done'){
                            if (bar) bar.style.width = '100%';
                            if (percent) percent.textContent = '100%';
                            if (status) status.textContent = nk('Game added!');
                            const cancelBtn = overlay ? overlay.querySelector('.newkey-cancel-btn') : null;
                            if (cancelBtn) cancelBtn.style.display = 'none';
                            const hideBtn = overlay ? overlay.querySelector('.newkey-hide-btn') : null;
                            if (hideBtn) hideBtn.innerHTML = '<span>' + nk('Close') + '</span>';
                            if (wrap || percent) {
                            setTimeout(function(){ if (wrap) wrap.style.display = 'none'; if (percent) percent.style.display = 'none'; }, 300);
                            }
                            done = true; clearInterval(timer);
                            runState.inProgress = false; runState.appid = null;
                            const btnEl = document.querySelector('.newkey-button');
                            if (btnEl && btnEl.parentElement) {
                                btnEl.parentElement.removeChild(btnEl);
                            }
                        }
                        if (st.status === 'failed'){
                            if (status) status.textContent = nk('Failed: {error}').replace('{error}', st.error || nk('Unknown error'));
                            const cancelBtn = overlay ? overlay.querySelector('.newkey-cancel-btn') : null;
                            if (cancelBtn) cancelBtn.style.display = 'none';
                            const hideBtn = overlay ? overlay.querySelector('.newkey-hide-btn') : null;
                            if (hideBtn) hideBtn.innerHTML = '<span>' + nk('Close') + '</span>';
                            if (wrap) wrap.style.display = 'none';
                            if (percent) percent.style.display = 'none';
                            done = true; clearInterval(timer);
                            runState.inProgress = false; runState.appid = null;
                        }
                    } catch(_){ }
                });
            } catch(_){ clearInterval(timer); }
        }, 300);
    }
    
    setTimeout(addNewKeyButton, 1000);
    setTimeout(addNewKeyButton, 3000);
    
    let lastUrl = window.location.href;
    function checkUrlChange() {
        const currentUrl = window.location.href;
        if (currentUrl !== lastUrl) {
            lastUrl = currentUrl;
            window.__NewKeyButtonInserted = false;
            window.__NewKeyRestartInserted = false;
            window.__NewKeyIconInserted = false;
            window.__NewKeyPresenceCheckInFlight = false;
            window.__NewKeyPresenceCheckAppId = undefined;
            ensureTranslationsLoaded(false).then(function() {
                updateButtonTranslations();
                addNewKeyButton();
            });
        }
    }
    setInterval(checkUrlChange, 500);
    window.addEventListener('popstate', checkUrlChange);
    const originalPushState = history.pushState;
    const originalReplaceState = history.replaceState;
    history.pushState = function() {
        originalPushState.apply(history, arguments);
        setTimeout(checkUrlChange, 100);
    };
    history.replaceState = function() {
        originalReplaceState.apply(history, arguments);
        setTimeout(checkUrlChange, 100);
    };
    
    if (typeof MutationObserver !== 'undefined') {
        const observer = new MutationObserver(function(mutations) {
            mutations.forEach(function(mutation) {
                if (mutation.type === 'childList' && mutation.addedNodes.length > 0) {
                    updateButtonTranslations();
                    addNewKeyButton();
                }
            });
        });
        
        observer.observe(document.body, {
            childList: true,
            subtree: true
        });
    }

    function showLoadedAppsPopup(apps) {
        if (document.querySelector('.newkey-loadedapps-overlay')) return;
        ensureNewKeyStyles();
        const overlay = document.createElement('div');
        overlay.style.cssText = 'position:fixed;inset:0;background:rgba(5, 8, 15, 0.85);backdrop-filter:blur(16px);z-index:99999;display:flex;align-items:center;justify-content:center;animation:fadeIn 0.2s ease-out;';
        overlay.className = 'newkey-loadedapps-overlay';
        
        const modal = document.createElement('div');
        modal.style.cssText = 'background:linear-gradient(145deg, #0d1117 0%, #161b22 100%);color:#fff;border:1px solid rgba(255, 255, 255, 0.08);border-radius:16px;min-width:420px;max-width:640px;padding:32px;box-shadow:0 24px 48px rgba(0,0,0,0.8), 0 0 0 1px rgba(0, 212, 255, 0.1);animation:slideUp 0.3s cubic-bezier(0.25, 1, 0.5, 1);';
        
        const title = document.createElement('div');
        title.style.cssText = 'font-size:24px;font-weight:800;letter-spacing:0.5px;margin-bottom:24px;background:linear-gradient(135deg, #00d4ff 0%, #007bf5 100%);-webkit-background-clip:text;-webkit-text-fill-color:transparent;text-shadow:0 4px 12px rgba(0, 212, 255, 0.3);text-align:center;';
        title.textContent = nk('NewKey · Added Games');
        
        const body = document.createElement('div');
        body.className = 'newkey-scroll';
        body.style.cssText = 'font-size:14px;line-height:1.8;margin-bottom:24px;max-height:320px;overflow:auto;padding:20px;border:1px solid rgba(255, 255, 255, 0.05);border-radius:12px;background:rgba(5, 8, 15, 0.4);box-shadow:inset 0 4px 20px rgba(0,0,0,0.5);';
        
        if (apps && apps.length) {
            const list = document.createElement('div');
            apps.forEach(function(item){
                const a = document.createElement('a');
                a.href = 'steam://install/' + String(item.appid);
                a.textContent = String(item.name || item.appid);
                a.style.cssText = 'display:block;color:#e6edf3;text-decoration:none;padding:12px 16px;margin-bottom:8px;background:rgba(0, 212, 255, 0.05);border:1px solid rgba(0, 212, 255, 0.1);border-radius:8px;transition:all 0.3s cubic-bezier(0.25, 1, 0.5, 1);font-weight:500;';
                a.onmouseover = function() { this.style.background = 'rgba(0, 212, 255, 0.15)'; this.style.borderColor = 'rgba(0, 212, 255, 0.4)'; this.style.transform = 'translateY(-2px)'; this.style.boxShadow = '0 8px 16px rgba(0, 212, 255, 0.15)'; this.style.color = '#fff'; };
                a.onmouseout = function() { this.style.background = 'rgba(0, 212, 255, 0.05)'; this.style.borderColor = 'rgba(0, 212, 255, 0.1)'; this.style.transform = 'translateY(0)'; this.style.boxShadow = 'none'; this.style.color = '#e6edf3'; };
                a.onclick = function(e){ e.preventDefault(); try { window.location.href = a.href; } catch(_) {} };
                a.oncontextmenu = function(e){ e.preventDefault(); const url = 'https://steamdb.info/app/' + String(item.appid) + '/';
                    try { Millennium.callServerMethod('newkey', 'OpenExternalUrl', { url, contentScriptQuery: '' }); } catch(_) {}
                };
                list.appendChild(a);
            });
            body.appendChild(list);
        } else {
            body.style.textAlign = 'center';
            body.style.color = '#8b949e';
            body.textContent = nk('No games found.');
        }
        
        const btnRow = document.createElement('div');
        btnRow.style.cssText = 'display:flex;gap:16px;justify-content:space-between;align-items:center;';
        const instructionText = document.createElement('div');
        instructionText.style.cssText = 'font-size:13px;color:#8b949e;font-weight:500;';
        instructionText.textContent = nk('Left click to install, Right click for SteamDB');
        const dismissBtn = document.createElement('a');
        dismissBtn.className = 'newkey-btn primary';
        dismissBtn.innerHTML = '<span>' + nk('Dismiss') + '</span>';
        dismissBtn.href = '#';
        dismissBtn.onclick = function(e){ e.preventDefault(); try { Millennium.callServerMethod('newkey', 'DismissLoadedApps', { contentScriptQuery: '' }); } catch(_) {} try { sessionStorage.setItem('NewKeyLoadedAppsShown', '1'); } catch(_) {} overlay.remove(); };
        btnRow.appendChild(instructionText);
        btnRow.appendChild(dismissBtn);
        modal.appendChild(title);
        modal.appendChild(body);
        modal.appendChild(btnRow);
        overlay.appendChild(modal);
        overlay.addEventListener('click', function(e){ if (e.target === overlay) overlay.remove(); });
        document.body.appendChild(overlay);
    }
})();